package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"source2metal/internal/cb2pgn"
)

// prepareChessBaseSources uses the preserved CB2PGN v0.1.3 decoders as
// adapters. Their neutral PGN is written only below TEMP and then fed into the
// same RAW_GAMES parser/deduplicator as ordinary PGN input. TEMP is removed
// after a successful Source2Metal run.
func prepareChessBaseSources(inv Inventory, layout OutputLayout, c *Counters) []Source {
	var dbs []Source
	for _, s := range inv.Sources {
		if s.Kind == KindCBH || s.Kind == Kind2CBH {
			dbs = append(dbs, s)
		}
	}
	if len(dbs) == 0 {
		return nil
	}
	sort.Slice(dbs, func(i, j int) bool { return strings.ToLower(dbs[i].Path) < strings.ToLower(dbs[j].Path) })

	fmt.Println("\nChessBase-adapters: CB2PGN v0.1.3 wordt ongewijzigd als decoderbasis gebruikt.")
	fmt.Println("De adapter-PGN blijft tijdelijk onder TEMP; alleen de gezamenlijke RAW_GAMES is eindproduct.")

	var out []Source
	for i, s := range dbs {
		format := string(s.Kind)
		if s.Kind == KindCBH {
			c.CBHSetsProcessed++
		} else {
			c.TwoCBHSetsProcessed++
		}
		fmt.Printf("\nChessBase %d/%d: %s (%s)\n", i+1, len(dbs), s.Base, format)
		if !s.Complete {
			fmt.Println("  OVERGESLAGEN: bestandenset is onvolledig.")
			if s.Kind == KindCBH {
				c.CBHSetsFailed++
			} else {
				c.TwoCBHSetsFailed++
			}
			_ = writeCBAdapterReport(layout.ReportDir, s, cb2pgn.Stats{}, "ONVOLLEDIG", fmt.Errorf("onvolledige %s-bestandenset", format))
			continue
		}

		tmpDir := filepath.Join(layout.TempDir, "CB2PGN")
		if err := os.MkdirAll(tmpDir, 0755); err != nil {
			fmt.Println("  MISLUKT:", err)
			continue
		}
		tmp := filepath.Join(tmpDir, fmt.Sprintf("%03d_%s_%s_Raw.pgn", i+1, safeComponent(s.Base), format))
		start := time.Now()
		st, actualFormat, err := cb2pgn.ConvertFile(s.Path, tmp)
		if actualFormat != "" {
			format = actualFormat
		}
		if s.Kind == KindCBH {
			c.CBHRecords += st.Records
			c.CBHConverted += st.Converted
			c.CBHSkipped += st.Skipped
			c.CBHPlies += st.Plies
		} else {
			c.TwoCBHRecords += st.Records
			c.TwoCBHConverted += st.Converted
			c.TwoCBHSkipped += st.Skipped
			c.TwoCBHPlies += st.Plies
		}
		status := "KLAAR"
		if err != nil {
			status = "MISLUKT"
			if s.Kind == KindCBH {
				c.CBHSetsFailed++
			} else {
				c.TwoCBHSetsFailed++
			}
			fmt.Println("  MISLUKT:", err)
			_ = writeCBAdapterReport(layout.ReportDir, s, st, status, err)
			_ = os.Remove(tmp)
			continue
		}
		if s.Kind == KindCBH {
			c.CBHSetsBuilt++
		} else {
			c.TwoCBHSetsBuilt++
		}
		_ = writeCBAdapterReport(layout.ReportDir, s, st, status, nil)
		stFile, statErr := os.Stat(tmp)
		if statErr != nil {
			fmt.Println("  MISLUKT: tijdelijke adapter-PGN niet teruggevonden:", statErr)
			continue
		}
		fmt.Printf("  Adapter klaar: %s/%s partijen | %s ply | %s overgeslagen | %s\n",
			fmtInt(st.Converted), fmtInt(st.Records), fmtInt(st.Plies), fmtInt(st.Skipped), durShort(time.Since(start)))
		out = append(out, Source{
			Kind: KindPGN, Path: tmp, Base: s.Base, Bytes: stFile.Size(), Complete: true, Origin: s.Path,
		})
	}
	return out
}

func writeCBAdapterReport(reportDir string, src Source, st cb2pgn.Stats, status string, convErr error) error {
	if err := os.MkdirAll(reportDir, 0755); err != nil {
		return err
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - CB2PGN v0.1.3 adapterrapport\n\n", version)
	fmt.Fprintf(&b, "Bron           : %s\n", src.Path)
	fmt.Fprintf(&b, "Formaat        : %s\n", src.Kind)
	fmt.Fprintf(&b, "Status         : %s\n", status)
	fmt.Fprintf(&b, "Set compleet   : %v\n", src.Complete)
	fmt.Fprintf(&b, "Records fysiek : %s\n", fmtInt(st.Records))
	fmt.Fprintf(&b, "Niet-actief    : %s\n", fmtInt(st.Inactive))
	fmt.Fprintf(&b, "Geconverteerd  : %s\n", fmtInt(st.Converted))
	fmt.Fprintf(&b, "Overgeslagen   : %s\n", fmtInt(st.Skipped))
	fmt.Fprintf(&b, "Ply            : %s\n", fmtInt(st.Plies))
	fmt.Fprintf(&b, "Variatietakken : %s\n", fmtInt(st.Variations))
	if convErr != nil {
		fmt.Fprintf(&b, "Fout           : %v\n", convErr)
	}
	if len(st.Reasons) > 0 {
		fmt.Fprintln(&b, "\nOVERGESLAGEN - REDENEN")
		keys := make([]string, 0, len(st.Reasons))
		for k := range st.Reasons {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			fmt.Fprintf(&b, "%-72s %s\n", k, fmtInt(st.Reasons[k]))
		}
	}
	fmt.Fprintln(&b, "\nDe decoder is de geïntegreerde CB2PGN Builder v0.1.3-lijn.")
	fmt.Fprintln(&b, "De tijdelijke PGN gaat daarna door dezelfde Source2Metal RAW-filtering en exacte game-deduplicatie als gewone PGN-bronnen.")
	name := fmt.Sprintf("CB2PGN_%s_%s.txt", src.Kind, safeComponent(src.Base))
	return os.WriteFile(filepath.Join(reportDir, name), []byte(b.String()), 0644)
}
