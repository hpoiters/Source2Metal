package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type gameSig struct{ A, B uint64 }

type rawJob struct {
	seq  int64
	game PGNGame
}

type rejectKind int

const (
	rejectNone rejectKind = iota
	rejectNoResult
	rejectSetup
	rejectShort
	rejectElo
	rejectEloGap
)

type rawResult struct {
	seq      int64
	game     PGNGame
	toks     []string
	result   string
	sig      gameSig
	reject   rejectKind
	vars     int64
	comments int64
}

type fileProgress struct {
	bytesRead   atomic.Int64
	processed   atomic.Int64
	accepted    atomic.Int64
	duplicate   atomic.Int64
	rejected    atomic.Int64
	lastLineLen int
}

func buildRawGames(inv Inventory, outputPath string, cfg Config, c *Counters, extraSources ...Source) (string, error) {
	var pgns []Source
	for _, s := range inv.Sources {
		if s.Kind == KindPGN {
			pgns = append(pgns, s)
		}
	}
	pgns = append(pgns, extraSources...)
	if len(pgns) == 0 {
		return "", fmt.Errorf("geen GAME-bronnen beschikbaar voor RAW_GAMES")
	}
	sort.SliceStable(pgns, func(i, j int) bool {
		// Preserve the validated PGN baseline: native PGN sources are processed
		// before adapter PGNs, so a cross-source duplicate keeps the native PGN
		// record rather than a temporary ChessBase translation.
		pi, pj := 0, 0
		if pgns[i].Origin != "" {
			pi = 1
		}
		if pgns[j].Origin != "" {
			pj = 1
		}
		if pi != pj {
			return pi < pj
		}
		ki, kj := pgns[i].Path, pgns[j].Path
		if pgns[i].Origin != "" {
			ki = pgns[i].Origin
		}
		if pgns[j].Origin != "" {
			kj = pgns[j].Origin
		}
		return strings.ToLower(ki) < strings.ToLower(kj)
	})
	if err := os.MkdirAll(filepath.Dir(outputPath), 0755); err != nil {
		return "", err
	}
	f, err := os.Create(outputPath)
	if err != nil {
		return "", err
	}
	w := bufio.NewWriterSize(f, 8<<20)
	seen := make(map[gameSig]struct{}, 1<<20)

	closeWithErr := func(retErr error) (string, error) {
		_ = w.Flush()
		_ = f.Close()
		return "", retErr
	}

	for fi, s := range pgns {
		displayPath := s.Path
		if s.Origin != "" {
			displayPath = s.Origin + " [via CB2PGN v0.1.3]"
		}
		fmt.Printf("\nRAW %d/%d: %s\n", fi+1, len(pgns), displayPath)
		start := time.Now()
		fp := &fileProgress{}
		stopMon := make(chan struct{})
		monDone := make(chan struct{})
		go monitorRawProgress(fp, s.Bytes, cfg.Workers, start, stopMon, monDone)

		jobs := make(chan rawJob, maxInt(8, cfg.Workers*4))
		results := make(chan rawResult, maxInt(8, cfg.Workers*4))
		var wg sync.WaitGroup
		for i := 0; i < cfg.Workers; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for j := range jobs {
					results <- processRawJob(j, cfg)
				}
			}()
		}

		aggDone := make(chan error, 1)
		go func() {
			pending := make(map[int64]rawResult, cfg.Workers*4)
			next := int64(0)
			var firstErr error
			handle := func(r rawResult) {
				c.GamesSeen++
				fp.processed.Add(1)
				c.VariationsStripped += r.vars
				c.CommentsStripped += r.comments
				switch r.reject {
				case rejectNoResult:
					c.GamesNoResult++
					fp.rejected.Add(1)
					return
				case rejectSetup:
					c.GamesSetup++
					fp.rejected.Add(1)
					return
				case rejectShort:
					c.GamesShort++
					fp.rejected.Add(1)
					return
				case rejectElo:
					c.GamesElo++
					fp.rejected.Add(1)
					return
				case rejectEloGap:
					c.GamesEloGap++
					fp.rejected.Add(1)
					return
				}
				if _, ok := seen[r.sig]; ok {
					c.GamesDuplicate++
					fp.duplicate.Add(1)
					return
				}
				seen[r.sig] = struct{}{}
				outToks := r.toks
				if len(outToks) > cfg.MaxPly {
					outToks = outToks[:cfg.MaxPly]
				}
				if firstErr == nil {
					if err := writeRawGame(w, r.game, outToks, r.result); err != nil {
						firstErr = err
					}
				}
				if firstErr == nil {
					c.GamesAccepted++
					c.PlyWritten += int64(len(outToks))
					fp.accepted.Add(1)
				}
			}
			for r := range results {
				pending[r.seq] = r
				for {
					rr, ok := pending[next]
					if !ok {
						break
					}
					delete(pending, next)
					handle(rr)
					next++
				}
			}
			aggDone <- firstErr
		}()

		seq := int64(0)
		parseErr := parsePGNFile(s.Path, func(g PGNGame) error {
			if s.Origin != "" {
				g.Source = s.Origin
			}
			jobs <- rawJob{seq: seq, game: g}
			seq++
			return nil
		}, func(done, total int64) {
			fp.bytesRead.Store(done)
		})
		close(jobs)
		wg.Wait()
		close(results)
		aggErr := <-aggDone
		close(stopMon)
		<-monDone
		printRawProgressFinal(fp, s.Bytes, cfg.Workers, start)
		fmt.Printf("  Bestand klaar: gezien %s | RAW %s | duplicaten %s | afgewezen %s\n",
			fmtInt(fp.processed.Load()), fmtInt(fp.accepted.Load()), fmtInt(fp.duplicate.Load()), fmtInt(fp.rejected.Load()))
		if parseErr != nil {
			return closeWithErr(parseErr)
		}
		if aggErr != nil {
			return closeWithErr(aggErr)
		}
	}

	if err := w.Flush(); err != nil {
		return closeWithErr(err)
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	st, err := os.Stat(outputPath)
	if err == nil {
		c.OutputBytes = st.Size()
	}
	sha, err := fileSHA256(outputPath)
	if err == nil {
		c.OutputSHA256 = sha
	}
	return outputPath, nil
}

func processRawJob(j rawJob, cfg Config) rawResult {
	toks, res, vars, coms := stripMainline(j.game.MoveText)
	r := rawResult{seq: j.seq, game: j.game, toks: toks, result: res, vars: vars, comments: coms}
	if r.result == "" {
		r.result = j.game.Tags["Result"]
	}
	if r.result != "1-0" && r.result != "0-1" && r.result != "1/2-1/2" {
		r.reject = rejectNoResult
		return r
	}
	if j.game.Tags["SetUp"] == "1" || j.game.Tags["FEN"] != "" {
		r.reject = rejectSetup
		return r
	}
	if len(toks) < cfg.MinPly {
		r.reject = rejectShort
		return r
	}
	we, wok := parseElo(j.game.Tags, "WhiteElo")
	be, bok := parseElo(j.game.Tags, "BlackElo")
	if cfg.MinElo > 0 && (!wok || !bok || we < cfg.MinElo || be < cfg.MinElo) {
		r.reject = rejectElo
		return r
	}
	if cfg.MaxEloGap > 0 && wok && bok {
		d := we - be
		if d < 0 {
			d = -d
		}
		if d > cfg.MaxEloGap {
			r.reject = rejectEloGap
			return r
		}
	}
	fullKey := strings.Join(toks, "\x1f") + "|" + r.result + "|standard"
	h := sha256.Sum256([]byte(fullKey))
	r.sig = gameSig{binary.LittleEndian.Uint64(h[0:8]), binary.LittleEndian.Uint64(h[8:16])}
	return r
}

func monitorRawProgress(fp *fileProgress, total int64, workers int, start time.Time, stop <-chan struct{}, done chan<- struct{}) {
	defer close(done)
	t := time.NewTicker(750 * time.Millisecond)
	defer t.Stop()
	for {
		select {
		case <-stop:
			return
		case <-t.C:
			printRawProgress(fp, total, workers, start)
		}
	}
}

func printRawProgress(fp *fileProgress, total int64, workers int, start time.Time) {
	done := fp.bytesRead.Load()
	processed := fp.processed.Load()
	accepted := fp.accepted.Load()
	elapsed := time.Since(start)
	pct := 0.0
	if total > 0 {
		pct = 100 * float64(done) / float64(total)
		if pct > 100 {
			pct = 100
		}
	}
	secs := elapsed.Seconds()
	pps, mbps := 0.0, 0.0
	if secs > 0 {
		pps = float64(processed) / secs
		mbps = float64(done) / (1024 * 1024) / secs
	}
	eta := etaString(done, total, elapsed)
	bar := progressBar(pct, 20)
	line := fmt.Sprintf("[%s] %5.1f%% | P%s RAW%s dup%s afw%s | W%d | %s/s %.1fMB/s | T%s ETA%s",
		bar, pct,
		fmtCompactInt(processed), fmtCompactInt(accepted), fmtCompactInt(fp.duplicate.Load()), fmtCompactInt(fp.rejected.Load()),
		workers, fmtCompactRate(pps), mbps, durShort(elapsed), eta)
	// Eén compacte regel die met carriage return wordt overschreven. Daardoor
	// blijft de console rustig en ontstaat geen lange stroom statusregels.
	pad := 0
	if fp.lastLineLen > len(line) {
		pad = fp.lastLineLen - len(line)
	}
	fmt.Printf("\r  %s%s", line, strings.Repeat(" ", pad))
	fp.lastLineLen = len(line)
}

func printRawProgressFinal(fp *fileProgress, total int64, workers int, start time.Time) {
	fp.bytesRead.Store(total)
	printRawProgress(fp, total, workers, start)
	fmt.Println()
}

func progressBar(pct float64, width int) string {
	if width < 4 {
		width = 4
	}
	filled := int((pct/100)*float64(width) + 0.5)
	if filled < 0 {
		filled = 0
	}
	if filled > width {
		filled = width
	}
	return strings.Repeat("#", filled) + strings.Repeat("-", width-filled)
}

func fmtCompactInt(n int64) string {
	if n < 1000 {
		return fmt.Sprintf("%d", n)
	}
	if n < 1_000_000 {
		return fmt.Sprintf("%.1fk", float64(n)/1_000)
	}
	if n < 1_000_000_000 {
		return fmt.Sprintf("%.2fM", float64(n)/1_000_000)
	}
	return fmt.Sprintf("%.2fG", float64(n)/1_000_000_000)
}

func fmtCompactRate(v float64) string {
	if v < 1000 {
		return fmt.Sprintf("%.0f", v)
	}
	if v < 1_000_000 {
		return fmt.Sprintf("%.1fk", v/1_000)
	}
	return fmt.Sprintf("%.2fM", v/1_000_000)
}

func etaString(done, total int64, elapsed time.Duration) string {
	if total > 0 && done >= total {
		return "00:00"
	}
	if total <= 0 || done <= 0 || elapsed < 3*time.Second || done < 16<<20 {
		return "wordt berekend"
	}
	rate := float64(done) / elapsed.Seconds()
	if rate <= 0 {
		return "?"
	}
	remain := time.Duration(float64(total-done)/rate) * time.Second
	return durShort(remain)
}

func durShort(d time.Duration) string {
	if d < 0 {
		d = 0
	}
	d = d.Round(time.Second)
	h := int(d / time.Hour)
	m := int((d % time.Hour) / time.Minute)
	s := int((d % time.Minute) / time.Second)
	if h > 0 {
		return fmt.Sprintf("%02d:%02d:%02d", h, m, s)
	}
	return fmt.Sprintf("%02d:%02d", m, s)
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func writeRawGame(w io.Writer, g PGNGame, toks []string, res string) error {
	canonical := []string{"Event", "Site", "Date", "Round", "White", "Black", "Result", "WhiteElo", "BlackElo", "TimeControl"}
	written := map[string]bool{}
	for _, k := range canonical {
		v := g.Tags[k]
		if k == "Result" {
			v = res
		}
		if v != "" {
			if _, err := fmt.Fprintf(w, "[%s \"%s\"]\n", k, escapeTag(v)); err != nil {
				return err
			}
			written[k] = true
		}
	}
	for _, k := range g.TagOrder {
		if written[k] || k == "FEN" || k == "SetUp" {
			continue
		}
		if v := g.Tags[k]; v != "" {
			if _, err := fmt.Fprintf(w, "[%s \"%s\"]\n", k, escapeTag(v)); err != nil {
				return err
			}
			written[k] = true
		}
	}
	if _, err := fmt.Fprintf(w, "[Source2MetalVersion \"%s\"]\n[Source2MetalSource \"%s\"]\n\n", version, escapeTag(g.Source)); err != nil {
		return err
	}
	for i, m := range toks {
		if i%2 == 0 {
			if _, err := fmt.Fprintf(w, "%d. ", i/2+1); err != nil {
				return err
			}
		}
		if _, err := fmt.Fprint(w, m, " "); err != nil {
			return err
		}
	}
	if _, err := fmt.Fprintln(w, res); err != nil {
		return err
	}
	_, err := fmt.Fprintln(w)
	return err
}

func escapeTag(s string) string {
	s = strings.ReplaceAll(s, "\\", "\\\\")
	s = strings.ReplaceAll(s, "\"", "\\\"")
	return s
}

func fileSHA256(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", h.Sum(nil)), nil
}

func fmtInt(n int64) string {
	s := fmt.Sprintf("%d", n)
	for i := len(s) - 3; i > 0; i -= 3 {
		s = s[:i] + "." + s[i:]
	}
	return s
}
