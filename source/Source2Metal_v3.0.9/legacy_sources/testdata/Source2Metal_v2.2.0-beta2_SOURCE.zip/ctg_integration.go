package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"source2metal/internal/ctgmetal"
	"source2metal/internal/ctgraw"
)

func safeComponent(s string) string {
	r := strings.NewReplacer("\\", "_", "/", "_", ":", "_", "*", "_", "?", "_", "\"", "_", "<", "_", ">", "_", "|", "_")
	s = strings.TrimSpace(r.Replace(s))
	if s == "" {
		return "CTG"
	}
	return s
}

func completeCTGSources(inv Inventory) []Source {
	out := make([]Source, 0)
	for _, s := range inv.Sources {
		if s.Kind == KindCTG && s.Complete && len(s.Aux) >= 2 {
			out = append(out, s)
		}
	}
	return out
}

func buildRawBooks(inv Inventory, layout OutputLayout, cfg Config, c *Counters) ([]string, error) {
	sets := completeCTGSources(inv)
	if len(sets) == 0 {
		fmt.Println("Geen complete CTG-sets voor RAW_BOOKS; overgeslagen.")
		return nil, nil
	}
	var outputs []string
	for i, s := range sets {
		c.CTGSetsProcessed++
		bookDir := filepath.Join(layout.RawBooksDir, safeComponent(s.Base))
		if err := os.MkdirAll(bookDir, 0755); err != nil {
			return outputs, err
		}
		out := filepath.Join(bookDir, "Source2Metal_RAW_BOOKS.pgn")
		fmt.Printf("\nRAW_BOOKS %d/%d: %s\n", i+1, len(sets), s.Base)
		pr := newProgressRenderer()
		res, err := ctgraw.BuildNeutralWithProgress(s.Base, s.Path, s.Aux[0], s.Aux[1], out, cfg.MaxPly, func(text string, final bool) {
			if final {
				pr.Finish(func(width int) string { return "  " + text })
			} else {
				pr.Render(func(width int) string { return "  " + text })
			}
		})
		if err != nil {
			c.CTGRawFailed++
			_ = os.WriteFile(filepath.Join(bookDir, "RAW_BOOKS_FOUT.txt"), []byte(err.Error()+"\n"), 0644)
			fmt.Println("RAW_BOOKS MISLUKT:", err)
			continue
		}
		c.CTGRawBuilt++
		c.CTGRawGames += int64(res.Games)
		c.CTGRawPlies += res.Plies
		c.CTGRawBytes += res.Bytes
		c.CTGDecodeErrors += res.DecodeErrors
		outputs = append(outputs, out)
		fmt.Printf("RAW_BOOKS klaar: %d partijen | %.1f MB | decodefouten %d\n", res.Games, float64(res.Bytes)/(1024*1024), res.DecodeErrors)
	}
	return outputs, nil
}

func buildMetalFromCTG(inv Inventory, layout OutputLayout, cfg Config, c *Counters) error {
	sets := completeCTGSources(inv)
	if len(sets) == 0 {
		fmt.Println("Geen complete CTG-sets voor METAL; overgeslagen.")
		return nil
	}
	for i, s := range sets {
		outDir := filepath.Join(layout.MetalDir, safeComponent(s.Base))
		if err := os.MkdirAll(outDir, 0755); err != nil {
			return err
		}
		fmt.Printf("\nMETAL %d/%d: %s\n", i+1, len(sets), s.Base)
		pr := newProgressRenderer()
		res, err := ctgmetal.BuildMetalWithProgress(s.Base, s.Path, s.Aux[0], s.Aux[1], outDir, cfg.MaxPly, func(text string, final bool) {
			if text == "" {
				pr.Clear()
				return
			}
			if final {
				pr.Finish(func(width int) string { return text })
			} else {
				pr.Render(func(width int) string { return text })
			}
		})
		if err != nil {
			c.CTGMetalFailed++
			_ = os.WriteFile(filepath.Join(outDir, "METAL_FOUT.txt"), []byte(err.Error()+"\n"), 0644)
			fmt.Println("METAL MISLUKT:", err)
			continue
		}
		switch res.Status {
		case "KLAAR":
			c.CTGMetalBuilt++
			c.CTGMetalBytes += res.Bytes
			fmt.Printf("METAL klaar: %.1f MB\n", float64(res.Bytes)/(1024*1024))
		case "OVERGESLAGEN", "AFGEBROKEN":
			c.CTGMetalSkipped++
			fmt.Println("METAL:", res.Status)
		default:
			fmt.Println("METAL status:", res.Status)
		}
	}
	return nil
}
