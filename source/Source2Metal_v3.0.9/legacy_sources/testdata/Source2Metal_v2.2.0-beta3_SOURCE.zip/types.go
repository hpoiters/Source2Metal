package main

import "time"

const (
	version       = "2.2.0-beta3"
	defaultMaxPly = 100
	defaultMinPly = 24
	maxAllowedPly = 120
	buildDateUTC  = "2026-09-05T21:50:00Z"
)

type Config struct {
	Input         string
	Mode          string
	MaxPly        int
	MinPly        int
	MinElo        int
	MaxEloGap     int
	Workers       int
	NoPause       bool
	SelfTest      bool
	Interactive   bool
	ExtractSource bool
	BuildInfo     bool
	PagefileHelp  bool
}

type HardwareInfo struct {
	CPUName        string
	LogicalThreads int
	RAMBytes       int64
	PagefileBytes  int64
	PagefilePaths  string
	FreeBytes      int64
	RAMKnown       bool
	PagefileKnown  bool
	FreeKnown      bool
}

type SourceKind string

const (
	KindPGN  SourceKind = "PGN"
	KindCTG  SourceKind = "CTG"
	KindCBH  SourceKind = "CBH"
	Kind2CBH SourceKind = "2CBH"
)

type Source struct {
	Kind     SourceKind
	Path     string
	Base     string
	Bytes    int64
	Complete bool
	Aux      []string
	// Origin is the original source shown in RAW provenance when Path points
	// at a temporary adapter PGN. Empty means Path itself.
	Origin string
}

type Inventory struct {
	Root    string
	Sources []Source
}

type Counters struct {
	FilesPGN, SetsCTG, FilesCBH, Files2CBH                        int64
	GamesSeen, GamesAccepted, GamesDuplicate                      int64
	GamesNoResult, GamesSetup, GamesShort                         int64
	GamesElo, GamesEloGap, GamesMalformed                         int64
	VariationsStripped, CommentsStripped                          int64
	PlyWritten                                                    int64
	OutputBytes                                                   int64
	OutputSHA256                                                  string
	CTGSetsProcessed, CTGRawBuilt, CTGRawSkipped, CTGRawFailed    int64
	CTGRawGames, CTGRawPlies, CTGRawBytes, CTGDecodeErrors        int64
	RawGamesVerified, RawBooksVerified, CombinedVerified          int64
	CTGMetalBuilt, CTGMetalSkipped, CTGMetalFailed, CTGMetalBytes int64
	CBHSetsProcessed, CBHSetsBuilt, CBHSetsFailed                 int64
	CBHRecords, CBHConverted, CBHSkipped, CBHPlies                int64
	TwoCBHSetsProcessed, TwoCBHSetsBuilt, TwoCBHSetsFailed        int64
	TwoCBHRecords, TwoCBHConverted, TwoCBHSkipped, TwoCBHPlies    int64
	CombinedBytes                                                 int64
	CombinedGames                                                 int64
	CombinedSHA256                                                string
	Started                                                       time.Time
	Elapsed                                                       time.Duration
}

type PGNGame struct {
	Tags     map[string]string
	TagOrder []string
	MoveText string
	Source   string
}

type OutputLayout struct {
	RunDir         string
	RawDir         string
	RawGamesDir    string
	RawBooksDir    string
	RawCombinedDir string
	MetalDir       string
	ReportDir      string
	TempDir        string
	RawGamesFile   string
}
