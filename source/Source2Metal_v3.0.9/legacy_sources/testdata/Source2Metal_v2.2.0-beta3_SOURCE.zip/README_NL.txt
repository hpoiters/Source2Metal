Source2Metal v2.2.0-beta3
=========================

DOEL
Source2Metal wordt één gezamenlijke pijplijn voor RAW en METAL. Deze beta voegt
nu ook de bewaarde ChessBase-decoderlijn inhoudelijk toe: PGN, CBH, 2CBH en CTG
kunnen in één run samenkomen zonder dat werkende losse modules opnieuw worden
uitgevonden.

WAT DEZE BETA WERKELIJK DOET
- Recursieve broninventarisatie vanaf de EXE-map, nooit erboven.
- Herkent PGN, complete CTG/CTO/CTB-sets, complete CBH-sets en complete 2CBH-sets.
- Slaat !Source2Metal_Output, *_output, TEMP/tijdelijk en eigen uitvoer over.
- PGN -> RAW/GAMES via de praktisch gevalideerde parallelle beta3-pijplijn.
- CBH/2CBH -> tijdelijke neutrale PGN via de bewaarde CB2PGN Builder v0.1.3-
  decoder; daarna gaat die uitvoer door exact dezelfde RAW-filtering en
  deduplicatie als gewone PGN-bronnen.
- De tijdelijke CB2PGN-uitvoer staat alleen onder TEMP en wordt na een geslaagde
  run verwijderd; de originele ChessBase-databases blijven alleen-lezen.
- CTG -> RAW/BOOKS via de bewaarde CTGExtractor v2.4-lijn.
- CTG -> METAL via de bewaarde Ctg2Metal v2.1.0-lijn.
- Als zowel RAW_GAMES als RAW_BOOKS bestaan, wordt RAW_COMBINED streaming
  opgebouwd. GAME- en BOOK-RAW worden bewust niet cross-class ontdubbeld.
- Hardwaredetectie en standaard 50% van de logische CPU-threads blijven actief.
- Alleen outputmappen waarvoor werkelijk uitvoer bestaat blijven na afloop staan.
- EXE bevat een bronarchive; -extract-source haalt hem terug.

CHESSBASE-SETS
Klassieke CBH-set:
  .cbh + .cbg + .cbp + .cbt

Nieuwe 2CBH-set:
  .2cbh + .2cbg + .2lid

Een onvolledige set wordt niet stil verwerkt: hij wordt als ONVOLLEDIG gemeld en
in REPORT vastgelegd.

De geïntegreerde decoder is bewust zo dicht mogelijk bij de losse, werkende
CB2PGN Builder v0.1.3 gehouden. De exacte aangeleverde bronbundle is bovendien
ongewijzigd onder legacy_sources/testdata/ opgenomen.

UITVOER
!Source2Metal_Output/<tijdstempel>/
  RAW/
    GAMES/Source2Metal_RAW_GAMES.pgn
    BOOKS/<boek>/Source2Metal_RAW_BOOKS.pgn
    COMBINED/Source2Metal_RAW_COMBINED.pgn   (alleen als GAMES + BOOKS bestaan)
  METAL/<boek>/
    Source2Metal_METAL.pgn                   (alleen als selectie slaagt)
    Ctg2Metal_report.txt
    INSTRUCTIE_INLEREN.txt
  REPORT/
    Source2Metal_Report.txt
    Source2Metal_Settings.txt
    Source2Metal_Sources.txt
    CB2PGN_<formaat>_<database>.txt           (per CBH/2CBH-bron)
    Source2Metal_BuildInfo.txt
    Source2Metal_SourceExtract.txt
    Source2Metal_SHA256.txt
    STATUS_KLAAR.txt

AANBEVOLEN EERSTE TEST
Voor de regressietest kan interactief voorlopig overal Enter worden gebruikt:
  workers   = 50% van gedetecteerde logische threads
  modus     = 3 (RAW + METAL)
  max ply   = 100
  min ply   = 24
  Elo       = bronselectie behouden
  Elo-gap   = geen

Voor de huidige J:\Test-opstelling verwachten we dat de twee PGN's opnieuw
hetzelfde resultaat geven als v2.1.0-beta1, terwijl StrongGames2017 (CBH) en
MyInternetMachineGames (2CBH) nu werkelijk via CB2PGN worden toegevoegd aan
RAW_GAMES voordat de gezamenlijke exacte game-deduplicatie plaatsvindt.

LET OP BIJ CBH/2CBH
CB2PGN converteert eerst neutraal, hoofdvariant-only. Daarna gelden de gewone
Source2Metal RAW-keuzes (minimumlengte, Elo-filter, Elo-gap, max-ply en exacte
partij-deduplicatie). Het aantal uiteindelijk toegevoegde RAW_GAMES kan daarom
lager zijn dan het aantal dat de ChessBase-adapter zelf converteerde.

2CBH bouwt voort op de eerdere referentievalidering van 43/43 partijen,
3119/3119 ply en 0 overgeslagen. De klassieke CBH-route moet in deze integratie-
beta opnieuw in de praktijk worden bevestigd op StrongGames2017; de losse
CB2PGN-lijn had die database eerder vrijwel volledig geconverteerd.

VENSTER GROOT/KLEIN MAKEN
Vanaf v2.2.0-beta2 is de actieve voortgangsregel eigendom van Source2Metal.
Bij iedere update wordt de actuele zichtbare consolebreedte opnieuw gelezen.
De regel wordt zo nodig compacter gemaakt en oude rijen die door Windows na
een resize zijn omgevouwen, worden gewist voordat de actuele regel verschijnt.
Dit geldt voor CBH/2CBH-adapters, gewone PGN/RAW-voortgang en de geïntegreerde
CTG RAW_BOOKS/METAL-live-regels. De ChessBase- en CTG-decoders/selectielogica
zijn hierdoor inhoudelijk niet veranderd.

LET OP BIJ CTG
RAW_BOOKS is representatieve, neutrale PGN-uitvoer uit de CTG-boom. Het is geen
historische partijendatabase. METAL gebruikt voorlopig de Ctg2Metal-selectielogica.

FRITZ - GECORRIGEERDE INLEERINSTELLING VOOR METAL
Bij "Leren van database" / "Bijleren uit database":
  Overwinningen   AAN
  Verliespartijen AAN
  Wit             UIT
  Zwart           UIT
  Speler          UIT
  Spelernaam      LEEG
  Partijen        ALLE
Deze regel vervangt oudere Ctg2Metal-documentatie waarin nog "alle filters UIT"
stond.

WAAROM KAN EEN METAL-RECORD AL NA ZET 2 EINDIGEN MET 1-0?
Source2Metal_METAL.pgn bevat kunstmatige Fritz-leerrecords, geen gewone gespeelde
partijen. Het record stopt bij het geselecteerde Metal-anker. De uitslag 1-0 of
0-1 is een leersignaal voor de kleur die de ankerzet speelde, niet de echte
uitslag van een partij. Bijvoorbeeld "1.Na3 c5 2.e4 1-0" betekent dus niet dat
wit na 2.e4 won.

BRONCODEBEWARING
De SOURCE-archive bevat:
- actuele Source2Metal-code;
- geïntegreerde CTG-adapters;
- geïntegreerde CB2PGN v0.1.3-adapter;
- exacte originele aangeleverde CTG-bronnen;
- exacte originele CB2PGN v0.1.3-sourcebundle;
- Source2Metal v2.0.0-beta3 en v2.1.0-beta1 sourcearchives als herstelpunten.

Bron uit EXE halen:
  Source2Metal_v2.2.0-beta3.exe -extract-source

Build-info:
  Source2Metal_v2.2.0-beta3.exe -build-info

Pagefile-uitleg:
  Source2Metal_v2.2.0-beta3.exe -pagefile-help

BETASTATUS
- PGN/RAW is praktisch gevalideerd.
- CTG/RAW_BOOKS en CTG/METAL hebben een geslaagde geïntegreerde Fritz20-run.
- 2CBH-decoder is los eerder exact op een referentieset gevalideerd.
- CBH/2CBH zijn nu voor het eerst in dezelfde Source2Metal-EXE geïmplanteerd.
- De universele position-centric Evidence Engine voor alle bronsoorten volgt later.

LICENTIE
GPL v3 of later voor Source2Metal als geheel; zie LICENSE_GPL-3.0.txt en
THIRD_PARTY_NOTICES.txt.


BETA3 - CONTROLE- EN FAILPRESENTATIE
------------------------------------
- CTG-bronnen die geen verantwoord RAW_BOOKS- of METAL-product opleveren stoppen
  de batch niet meer voor een interactieve keuze. De console meldt compact:
  `overgeslagen - zie "Zie fail uitleg.txt" in submap.`
- De resultaatmap krijgt zichtbaar `[FAIL - ZIE UITLEG]` in de naam.
- `Zie fail uitleg.txt` bevat de volledige reden; bestaande detailrapporten blijven
  in die map bewaard. Er wordt geen lege of twijfelachtige PGN gemaakt.
- RAW_GAMES, RAW_BOOKS en RAW_COMBINED krijgen een structurele eindcontrole op het
  werkelijk teruggevonden aantal gegenereerde PGN-records.
- De dubbele 100%-regel bij CBH/2CBH is verwijderd.
- Bij klassieke CBH wordt een fysiek niet-actief/headerrecord expliciet apart
  getoond, zodat bijvoorbeeld 128.653 fysieke records / 128.652 partijen niet
  meer op een verdwenen schaakpartij lijkt.
- Zeer korte bestanden tonen geen misleidende 0/s-snelheid maar `snelheid n.v.t.`
- De eindstatus is `VOLLEDIG GESLAAGD` of `GEDEELTELIJK GESLAAGD`.
