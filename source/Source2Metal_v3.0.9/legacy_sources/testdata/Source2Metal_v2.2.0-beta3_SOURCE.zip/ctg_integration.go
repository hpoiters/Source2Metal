package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"source2metal/internal/ctgmetal"
	"source2metal/internal/ctgraw"
)

func safeComponent(s string) string {
	r := strings.NewReplacer("\\", "_", "/", "_", ":", "_", "*", "_", "?", "_", "\"", "_", "<", "_", ">", "_", "|", "_")
	s = strings.TrimSpace(r.Replace(s))
	if s == "" {
		return "CTG"
	}
	return s
}

func completeCTGSources(inv Inventory) []Source {
	out := make([]Source, 0)
	for _, s := range inv.Sources {
		if s.Kind == KindCTG && s.Complete && len(s.Aux) >= 2 {
			out = append(out, s)
		}
	}
	return out
}

func rawBookSkippable(err error) bool {
	if err == nil {
		return false
	}
	x := strings.ToLower(err.Error())
	return strings.Contains(x, "beginstelling niet gevonden") || strings.Contains(x, "positie niet in cto-index")
}

func buildRawBooks(inv Inventory, layout OutputLayout, cfg Config, c *Counters) ([]string, error) {
	sets := completeCTGSources(inv)
	if len(sets) == 0 {
		fmt.Println("Geen complete CTG-sets voor RAW_BOOKS; overgeslagen.")
		return nil, nil
	}
	var outputs []string
	for i, s := range sets {
		c.CTGSetsProcessed++
		bookDir := filepath.Join(layout.RawBooksDir, safeComponent(s.Base))
		if err := os.MkdirAll(bookDir, 0755); err != nil {
			return outputs, err
		}
		out := filepath.Join(bookDir, "Source2Metal_RAW_BOOKS.pgn")
		fmt.Printf("\nRAW_BOOKS %d/%d: %s\n", i+1, len(sets), s.Base)
		pr := newProgressRenderer()
		res, err := ctgraw.BuildNeutralWithProgress(s.Base, s.Path, s.Aux[0], s.Aux[1], out, cfg.MaxPly, func(text string, final bool) {
			if final {
				pr.Finish(func(width int) string { return "  " + text })
			} else {
				pr.Render(func(width int) string { return "  " + text })
			}
		})
		if err != nil {
			pr.Clear()
			_ = os.Remove(out)
			status := "MISLUKT"
			reason := fmt.Sprintf("RAW_BOOKS kon niet worden gemaakt.\n\nTechnische reden:\n%s", err)
			if rawBookSkippable(err) {
				c.CTGRawSkipped++
				status = "OVERGESLAGEN"
				reason = fmt.Sprintf("RAW_BOOKS is overgeslagen omdat de geïntegreerde CTGExtractor-route vanuit de normale beginstelling geen bruikbare ingang in deze CTG/CTO-index vond. Dit betekent niet automatisch dat het boek beschadigd is.\n\nTechnische diagnose:\n%s", err)
			} else {
				c.CTGRawFailed++
			}
			_, ferr := finalizeFailDir(bookDir, layout.RawBooksDir, s.Base, "RAW_BOOKS", status, reason, "")
			if ferr != nil {
				return outputs, ferr
			}
			fmt.Printf("RAW_BOOKS %s: %s - zie %q in submap.\n", s.Base, strings.ToLower(status), failExplanationName)
			continue
		}

		found, verr := countGeneratedPGNRecords(out)
		if verr != nil || found != int64(res.Games) {
			_ = os.Remove(out)
			c.CTGRawFailed++
			reason := fmt.Sprintf("RAW_BOOKS faalde bij de structurele eindcontrole. Verwacht %s records, teruggevonden %s.", fmtInt(int64(res.Games)), fmtInt(found))
			if verr != nil {
				reason += "\n\nEindcontrolefout: " + verr.Error()
			}
			_, ferr := finalizeFailDir(bookDir, layout.RawBooksDir, s.Base, "RAW_BOOKS", "MISLUKT", reason, "")
			if ferr != nil {
				return outputs, ferr
			}
			fmt.Printf("RAW_BOOKS %s: mislukt - zie %q in submap.\n", s.Base, failExplanationName)
			continue
		}

		c.CTGRawBuilt++
		c.CTGRawGames += int64(res.Games)
		c.CTGRawPlies += res.Plies
		c.CTGRawBytes += res.Bytes
		c.CTGDecodeErrors += res.DecodeErrors
		c.RawBooksVerified += found
		outputs = append(outputs, out)
		fmt.Printf("RAW_BOOKS klaar: %d partijen | %.1f MB | decodefouten %d | controle OK\n", res.Games, float64(res.Bytes)/(1024*1024), res.DecodeErrors)
	}
	return outputs, nil
}

func buildMetalFromCTG(inv Inventory, layout OutputLayout, cfg Config, c *Counters) error {
	sets := completeCTGSources(inv)
	if len(sets) == 0 {
		fmt.Println("Geen complete CTG-sets voor METAL; overgeslagen.")
		return nil
	}
	for i, s := range sets {
		outDir := filepath.Join(layout.MetalDir, safeComponent(s.Base))
		if err := os.MkdirAll(outDir, 0755); err != nil {
			return err
		}
		fmt.Printf("\nMETAL %d/%d: %s\n", i+1, len(sets), s.Base)
		pr := newProgressRenderer()
		res, err := ctgmetal.BuildMetalWithProgress(s.Base, s.Path, s.Aux[0], s.Aux[1], outDir, cfg.MaxPly, func(text string, final bool) {
			if text == "" {
				pr.Clear()
				return
			}
			if final {
				pr.Finish(func(width int) string { return text })
			} else {
				pr.Render(func(width int) string { return text })
			}
		})
		if err != nil {
			pr.Clear()
			c.CTGMetalFailed++
			_ = os.Remove(filepath.Join(outDir, "Metal.pgn"))
			_ = os.Remove(filepath.Join(outDir, "Source2Metal_METAL.pgn"))
			reason := "METAL kon door een technische fout niet worden gemaakt.\n\nTechnische reden:\n" + err.Error()
			if _, ferr := finalizeFailDir(outDir, layout.MetalDir, s.Base, "METAL", "MISLUKT", reason, "Ctg2Metal_report.txt"); ferr != nil {
				return ferr
			}
			fmt.Printf("METAL %s: mislukt - zie %q in submap.\n", s.Base, failExplanationName)
			continue
		}
		switch res.Status {
		case "KLAAR":
			c.CTGMetalBuilt++
			c.CTGMetalBytes += res.Bytes
			fmt.Printf("METAL klaar: %.1f MB\n", float64(res.Bytes)/(1024*1024))
		case "OVERGESLAGEN", "AFGEBROKEN":
			c.CTGMetalSkipped++
			_ = os.Remove(filepath.Join(outDir, "Metal.pgn"))
			_ = os.Remove(filepath.Join(outDir, "Source2Metal_METAL.pgn"))
			reason := "De CTG-bron is gelezen, maar de standaard Metal-selectie vond geen voldoende betrouwbaar leersignaal. Source2Metal verlaagt de bewijslast niet automatisch en maakt daarom geen lege of twijfelachtige Metal.pgn. De volledige selectie-diagnose staat hieronder in het Ctg2Metal-rapport."
			if _, ferr := finalizeFailDir(outDir, layout.MetalDir, s.Base, "METAL", "OVERGESLAGEN / GEEN OUTPUT", reason, "Ctg2Metal_report.txt"); ferr != nil {
				return ferr
			}
			fmt.Printf("METAL %s: overgeslagen - zie %q in submap.\n", s.Base, failExplanationName)
		default:
			c.CTGMetalFailed++
			reason := "METAL eindigde met een onbekende status: " + res.Status
			if _, ferr := finalizeFailDir(outDir, layout.MetalDir, s.Base, "METAL", "MISLUKT", reason, "Ctg2Metal_report.txt"); ferr != nil {
				return ferr
			}
			fmt.Printf("METAL %s: mislukt - zie %q in submap.\n", s.Base, failExplanationName)
		}
	}
	return nil
}
