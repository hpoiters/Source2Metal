# Source2Metal V2 — beta-specificatie

Versie: **2.2.0-beta2**

## Hoofddoel
Eén versieerbare Source2Metal-pijplijn waarin PGN, CBH, 2CBH en CTG onder één
programma samenkomen. RAW blijft het brede, neutrale fundament; METAL blijft een
afzonderlijke, toetsbare leerlaag.

## Bronnen
Recursief vanaf de EXE-map, nooit erboven:
- PGN — inhoudelijk actief
- CBH + CBG + CBP + CBT — inhoudelijk actief via CB2PGN v0.1.3-adapter
- 2CBH + 2CBG + 2LID — inhoudelijk actief via CB2PGN v0.1.3-adapter
- CTG + CTO + CTB — inhoudelijk actief

`!Source2Metal_Output`, herkenbare `*_output`-mappen en tijdelijke mappen worden
niet opnieuw als bron gelezen.

## RAW
### RAW_GAMES
GAME-bronnen zijn PGN, CBH en 2CBH.

PGN gaat rechtstreeks door de bestaande RAW-pijplijn. CBH/2CBH worden eerst met
de bewaarde CB2PGN v0.1.3-decoder naar een tijdelijke neutrale PGN onder TEMP
omgezet. Die tijdelijke PGN wordt daarna door exact dezelfde RAW-filtering en
exacte game-deduplicatie gestuurd. Provenance wijst naar de oorspronkelijke
`.cbh` of `.2cbh`, niet naar het TEMP-bestand.

Filterregels:
- hoofdvariant;
- commentaren/varianten verwijderd waar van toepassing;
- minimum partij-lengte;
- optionele beide-spelers-Elo-drempel;
- optionele maximale Elo-afstand;
- exacte partijduplicaten op volledige hoofdvariant + resultaat vóór
  outputtruncatie;
- output maximaal gekozen RAW-diepte.

De CB2PGN-adapter zelf blijft neutraal en doet geen Metal-selectie of leerweging.

### RAW_BOOKS
CTG-boom -> neutrale representatieve PGN via de geïntegreerde CTGExtractor v2.4-
lijn. Donor recommendation/Fact wordt niet als objectief sterktesignaal overgenomen.

### RAW_COMBINED
Alleen als zowel GAMES als BOOKS bestaan. Streaming concatenatie. Geen cross-class
deduplicatie omdat echte partijen en boeklijnen verschillende bewijssoorten zijn.

## METAL
CTG -> `Source2Metal_METAL.pgn` via geïntegreerde Ctg2Metal v2.1.0-logica. Dit
blijft een adapterlaag totdat de algemene Evidence Engine bronsoorten position-
centric kan combineren.

Metal.pgn bevat synthetische leerrecords. Een korte recorduitslag (`1-0`/`0-1`)
is een leersignaal voor de kleur die het geselecteerde anker speelde en is niet
de historische uitslag van een echte partij.

Gecorrigeerde Fritz-inleerinstelling:
- Overwinningen AAN
- Verliespartijen AAN
- Wit UIT
- Zwart UIT
- Speler UIT
- spelernaam leeg
- alle partijen

## ChessBase-adapter
De geïntegreerde bron komt uit **CB2PGN Builder v0.1.3**:
- klassieke CBH-decoder: Go-port van Dominik Klein `cbh2pgn-0.1`, met de v0.1.3
  NUL-byte/tagreinigingsfix;
- 2CBH-decoder: eerder referentie-gevalideerd op 43/43 partijen, 3119/3119 ply,
  0 overgeslagen;
- legale zetcontrole en eigen SAN;
- hoofdvariant-only.

De exacte oorspronkelijke v0.1.3-sourcebundle is ongewijzigd als legacy-bron
opgenomen. De geïntegreerde kopie wijzigt alleen wat nodig is om hem als interne
adapter aan te roepen.

## Parallelle verwerking
Per pc hardwaredetectie; standaard 50% van gedetecteerde logische CPU-threads.
PGN RAW gebruikt werkelijk een worker-pool. CB2PGN en CTG behouden hun bewezen
decoderlogica. Vanaf v2.2.0-beta2 schrijft de geïntegreerde CB2PGN-adapter zijn
voortgang echter niet meer rechtstreeks naar de console: de decoder meldt alleen
status via een callback en Source2Metal rendert die resize-robust. Dezelfde renderer
wordt voor PGN/RAW en de geïntegreerde CTG RAW_BOOKS/METAL-live-regels gebruikt.
Inhoudelijke decoder- en selectielogica blijft ongewijzigd.

## Uitvoer
```
!Source2Metal_Output/<timestamp>/
  RAW/
    GAMES/Source2Metal_RAW_GAMES.pgn
    BOOKS/<book>/Source2Metal_RAW_BOOKS.pgn
    COMBINED/Source2Metal_RAW_COMBINED.pgn
  METAL/<book>/Source2Metal_METAL.pgn
  REPORT/
    CB2PGN_<format>_<database>.txt
    ...
  TEMP/   (na succes verwijderd)
```
Lege resultaatmappen worden niet bewust behouden.

## Bronbehoud
De release-source bevat:
- actuele Source2Metal-code;
- geïntegreerde CB2PGN/CTG-adapters;
- exacte originele bronbestanden/bundles onder `legacy_sources/`;
- vorige Source2Metal sourcearchives als herstelpunten;
- build- en extractie-informatie.

## Open vervolgpunten
- geïntegreerde StrongGames2017-CBH regressietest;
- geïntegreerde MyInternetMachineGames-2CBH regressietest;
- RAW_GAMES eindtotaal en provenance in ChessBase controleren;
- CTG RAW_BOOKS resterend-tijd format `0ss00ss` corrigeren;
- algemene position-centric Evidence Engine;
- hervatbare/checkpoint-runs.


## v2.2.0-beta3 resultaat- en failbeleid

- Iedere aangevraagde CTG-productroute levert óf een echt product óf een zichtbare
  `<Bron> [FAIL - ZIE UITLEG]`-map met `Zie fail uitleg.txt`.
- Geen lege product-PGN om een batch optisch compleet te laten lijken.
- Console blijft kort; volledige diagnose staat in de submap/rapporten.
- Geen interactieve V/Enter-blokkade bij zero-Metal in geïntegreerde batchmodus.
- Strikte Metal-policy blijft intact; geen automatische lagere bewijslast.
- RAW_GAMES, RAW_BOOKS en RAW_COMBINED worden na schrijven structureel geteld.
- Klassieke CBH onderscheidt fysieke records, niet-actieve/headerrecords,
  geconverteerde partijen en werkelijk overgeslagen partijen.
