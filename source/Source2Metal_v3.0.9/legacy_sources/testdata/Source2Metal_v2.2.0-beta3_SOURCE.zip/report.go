package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

func writeReports(layout OutputLayout, inv Inventory, cfg Config, hw HardwareInfo, c Counters, status string) error {
	if err := os.MkdirAll(layout.ReportDir, 0755); err != nil {
		return err
	}
	if err := writeInventoryReport(filepath.Join(layout.ReportDir, "Source2Metal_Report.txt"), inv, cfg, hw, c, status); err != nil {
		return err
	}
	if err := writeSettings(filepath.Join(layout.ReportDir, "Source2Metal_Settings.txt"), inv, cfg, hw); err != nil {
		return err
	}
	if err := writeSources(filepath.Join(layout.ReportDir, "Source2Metal_Sources.txt"), inv); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "Source2Metal_BuildInfo.txt"), []byte(buildInfoText()), 0644); err != nil {
		return err
	}
	extractInfo := fmt.Sprintf(`Source2Metal v%s - bronextractie uit de EXE

De Windows-EXE bevat een ingebedde bronarchive van deze release.

Gebruik in een opdrachtprompt in dezelfde map:
  Source2Metal_v%s.exe -extract-source

De EXE schrijft dan naast zichzelf:
  Source2Metal_v%s_EXTRACTED_SOURCE.zip

Ingebedde bron SHA-256:
  %s

Build-info bekijken zonder een run te starten:
  Source2Metal_v%s.exe -build-info

Pagefile-instructie bekijken:
  Source2Metal_v%s.exe -pagefile-help
`, version, version, version, embeddedSourceSHA256(), version, version)
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "Source2Metal_SourceExtract.txt"), []byte(extractInfo), 0644); err != nil {
		return err
	}
	statusText := fmt.Sprintf("Source2Metal v%s\nStatus: %s\nModus: %s\nWorkers: %d/%d\nRAW_GAMES partijen: %d\nRAW_GAMES geverifieerd: %d\nCBH adapters: %d geslaagd / %d mislukt\n2CBH adapters: %d geslaagd / %d mislukt\nRAW_BOOKS partijen: %d\nCTG METAL geslaagd: %d\nVerstreken: %s\n", version, status, cfg.Mode, cfg.Workers, hw.LogicalThreads, c.GamesAccepted, c.RawGamesVerified, c.CBHSetsBuilt, c.CBHSetsFailed, c.TwoCBHSetsBuilt, c.TwoCBHSetsFailed, c.CTGRawGames, c.CTGMetalBuilt, c.Elapsed)
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "STATUS_"+status+".txt"), []byte(statusText), 0644); err != nil {
		return err
	}
	return writeChecksums(filepath.Join(layout.ReportDir, "Source2Metal_SHA256.txt"), layout.RunDir)
}

func writeInventoryReport(path string, inv Inventory, cfg Config, hw HardwareInfo, c Counters, status string) error {
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - BETA RAPPORT\n\n", version)
	fmt.Fprintf(&b, "Status            : %s\n", status)
	fmt.Fprintf(&b, "Root              : %s\n", inv.Root)
	fmt.Fprintf(&b, "Modus             : %s\n", cfg.Mode)
	fmt.Fprintf(&b, "Workers           : %d / %d logische threads\n", cfg.Workers, hw.LogicalThreads)
	if hw.CPUName != "" {
		fmt.Fprintf(&b, "CPU               : %s\n", hw.CPUName)
	}
	if hw.RAMKnown {
		fmt.Fprintf(&b, "RAM               : %.1f GB\n", gib(hw.RAMBytes))
	}
	if hw.PagefileKnown {
		fmt.Fprintf(&b, "Pagefile          : %.1f GB", gib(hw.PagefileBytes))
		if hw.PagefilePaths != "" {
			fmt.Fprintf(&b, " | %s", hw.PagefilePaths)
		}
		fmt.Fprintln(&b)
	}
	if hw.FreeKnown {
		fmt.Fprintf(&b, "Vrij bij start    : %.1f GB\n", gib(hw.FreeBytes))
	}
	fmt.Fprintf(&b, "Max diepte        : %d ply\n", cfg.MaxPly)
	fmt.Fprintf(&b, "Minimum partij    : %d ply\n", cfg.MinPly)
	if cfg.MinElo == 0 {
		fmt.Fprintln(&b, "Elo-filter        : bronselectie behouden")
	} else {
		fmt.Fprintf(&b, "Elo-filter        : beide spelers >= %d\n", cfg.MinElo)
	}
	if cfg.MaxEloGap == 0 {
		fmt.Fprintln(&b, "Max Elo-verschil : geen")
	} else {
		fmt.Fprintf(&b, "Max Elo-verschil : %d\n", cfg.MaxEloGap)
	}
	fmt.Fprintf(&b, "Verstreken        : %s\n", c.Elapsed)
	fmt.Fprintf(&b, "Embedded source   : %s\n", embeddedSourceSHA256())

	fmt.Fprintln(&b, "\nBRONNEN")
	for _, s := range inv.Sources {
		status := ""
		if !s.Complete {
			status = " | ONVOLLEDIG"
		}
		fmt.Fprintf(&b, "%-4s | %s%s\n", s.Kind, s.Path, status)
	}
	fmt.Fprintln(&b, "\nRAW_GAMES")
	fmt.Fprintf(&b, "Partijen gezien      : %s\n", fmtInt(c.GamesSeen))
	fmt.Fprintf(&b, "Geaccepteerd         : %s\n", fmtInt(c.GamesAccepted))
	fmt.Fprintf(&b, "Exact duplicaat      : %s\n", fmtInt(c.GamesDuplicate))
	fmt.Fprintf(&b, "Geen geldige uitslag : %s\n", fmtInt(c.GamesNoResult))
	fmt.Fprintf(&b, "FEN/SetUp            : %s\n", fmtInt(c.GamesSetup))
	fmt.Fprintf(&b, "Te kort              : %s\n", fmtInt(c.GamesShort))
	fmt.Fprintf(&b, "Elo-filter           : %s\n", fmtInt(c.GamesElo))
	fmt.Fprintf(&b, "Elo-verschil         : %s\n", fmtInt(c.GamesEloGap))
	fmt.Fprintf(&b, "Variatietakken weg   : %s\n", fmtInt(c.VariationsStripped))
	fmt.Fprintf(&b, "Commentaren weg      : %s\n", fmtInt(c.CommentsStripped))
	fmt.Fprintf(&b, "Ply geschreven       : %s\n", fmtInt(c.PlyWritten))
	if c.OutputBytes > 0 {
		fmt.Fprintf(&b, "RAW bytes            : %d\nRAW SHA-256          : %s\n", c.OutputBytes, c.OutputSHA256)
	}

	fmt.Fprintln(&b, "\nCHESSBASE-ADAPTERS (CB2PGN v0.1.3)")
	fmt.Fprintf(&b, "CBH sets geprobeerd        : %s\n", fmtInt(c.CBHSetsProcessed))
	fmt.Fprintf(&b, "CBH sets geslaagd          : %s\n", fmtInt(c.CBHSetsBuilt))
	fmt.Fprintf(&b, "CBH sets mislukt           : %s\n", fmtInt(c.CBHSetsFailed))
	fmt.Fprintf(&b, "CBH fysieke records        : %s\n", fmtInt(c.CBHRecords))
	fmt.Fprintf(&b, "CBH adapterpartijen        : %s\n", fmtInt(c.CBHConverted))
	fmt.Fprintf(&b, "CBH adapter overgeslagen   : %s\n", fmtInt(c.CBHSkipped))
	fmt.Fprintf(&b, "CBH adapter ply            : %s\n", fmtInt(c.CBHPlies))
	fmt.Fprintf(&b, "2CBH sets geprobeerd       : %s\n", fmtInt(c.TwoCBHSetsProcessed))
	fmt.Fprintf(&b, "2CBH sets geslaagd         : %s\n", fmtInt(c.TwoCBHSetsBuilt))
	fmt.Fprintf(&b, "2CBH sets mislukt          : %s\n", fmtInt(c.TwoCBHSetsFailed))
	fmt.Fprintf(&b, "2CBH fysieke records       : %s\n", fmtInt(c.TwoCBHRecords))
	fmt.Fprintf(&b, "2CBH adapterpartijen       : %s\n", fmtInt(c.TwoCBHConverted))
	fmt.Fprintf(&b, "2CBH adapter overgeslagen  : %s\n", fmtInt(c.TwoCBHSkipped))
	fmt.Fprintf(&b, "2CBH adapter ply           : %s\n", fmtInt(c.TwoCBHPlies))

	fmt.Fprintln(&b, "\nCTG-INTEGRATIE")
	fmt.Fprintf(&b, "Complete CTG-sets verwerkt : %s\n", fmtInt(c.CTGSetsProcessed))
	fmt.Fprintf(&b, "RAW_BOOKS geslaagd         : %s\n", fmtInt(c.CTGRawBuilt))
	fmt.Fprintf(&b, "RAW_BOOKS overgeslagen     : %s\n", fmtInt(c.CTGRawSkipped))
	fmt.Fprintf(&b, "RAW_BOOKS mislukt          : %s\n", fmtInt(c.CTGRawFailed))
	fmt.Fprintf(&b, "RAW_BOOKS partijen         : %s\n", fmtInt(c.CTGRawGames))
	fmt.Fprintf(&b, "RAW_BOOKS geverifieerd     : %s\n", fmtInt(c.RawBooksVerified))
	fmt.Fprintf(&b, "RAW_BOOKS ply              : %s\n", fmtInt(c.CTGRawPlies))
	fmt.Fprintf(&b, "RAW_BOOKS bytes            : %s\n", fmtInt(c.CTGRawBytes))
	fmt.Fprintf(&b, "CTG decodefouten           : %s\n", fmtInt(c.CTGDecodeErrors))
	fmt.Fprintf(&b, "METAL geslaagd             : %s\n", fmtInt(c.CTGMetalBuilt))
	fmt.Fprintf(&b, "METAL overgeslagen         : %s\n", fmtInt(c.CTGMetalSkipped))
	fmt.Fprintf(&b, "METAL mislukt              : %s\n", fmtInt(c.CTGMetalFailed))
	fmt.Fprintf(&b, "METAL bytes                : %s\n", fmtInt(c.CTGMetalBytes))
	if c.CombinedBytes > 0 {
		fmt.Fprintf(&b, "RAW_COMBINED records       : %s\n", fmtInt(c.CombinedGames))
		fmt.Fprintf(&b, "RAW_COMBINED geverifieerd  : %s\n", fmtInt(c.CombinedVerified))
		fmt.Fprintf(&b, "RAW_COMBINED bytes         : %s\n", fmtInt(c.CombinedBytes))
		fmt.Fprintf(&b, "RAW_COMBINED SHA-256       : %s\n", c.CombinedSHA256)
	}
	fmt.Fprintln(&b, "\nV2.2.0-BETA3 STATUS / VANGRAILS")
	fmt.Fprintln(&b, "- PGN -> RAW_GAMES blijft de gevalideerde beta3-pijplijn; nog geen volledige legale schaakbordvalidator voor externe PGN.")
	fmt.Fprintln(&b, "- CBH/2CBH -> tijdelijke neutrale PGN gebruikt de bewaarde CB2PGN Builder v0.1.3-decoder en stroomt daarna door dezelfde RAW-filtering/deduplicatie.")
	fmt.Fprintln(&b, "- De 2CBH-decoder bouwt voort op de eerder exact gevalideerde 43/43 partijen, 3119/3119 ply, 0 overgeslagen proef.")
	fmt.Fprintln(&b, "- De klassieke CBH-route is praktisch geïntegreerd met StrongGames2017. Een fysiek niet-actief/headerrecord kan in de fysieke teller voorkomen zonder een ontbrekende schaakpartij te betekenen; het adapterrapport toont dit afzonderlijk.")
	fmt.Fprintln(&b, "- CTG -> RAW_BOOKS gebruikt de bewaarde CTGExtractor v2.4-lijn; donor-markeringen/recommendaties worden genegeerd.")
	fmt.Fprintln(&b, "- CTG -> METAL gebruikt de bewaarde Ctg2Metal v2.1.0-lijn; inhoudelijke kwaliteit blijft te testen.")
	fmt.Fprintln(&b, "- RAW_COMBINED is een streaming concatenatie van GAME- en BOOK-RAW. Er wordt bewust geen cross-class deduplicatie toegepast. RAW_GAMES/RAW_BOOKS/COMBINED krijgen een structurele record-eindcontrole.")
	fmt.Fprintln(&b, "- CTG-bronnen zonder verantwoord product krijgen een opvallende [FAIL - ZIE UITLEG]-submap; batchverwerking loopt automatisch door zonder lange console-diagnose.")
	fmt.Fprintln(&b, "- Gecorrigeerde Fritz-inleerinstelling voor Metal: Overwinningen + Verliespartijen AAN; Wit/Zwart/Speler UIT; spelernaam leeg.")
	fmt.Fprintln(&b, "- Metal.pgn bevat kunstmatige leerrecords: een korte recorduitslag is een leersignaal, geen bewering dat een echte partij daar eindigde.")
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeSettings(path string, inv Inventory, cfg Config, hw HardwareInfo) error {
	text := fmt.Sprintf(`Source2Metal v%s - instellingen

Root              : %s
Mode              : %s
MaxPly            : %d
MinPly            : %d
MinElo            : %d
MaxEloGap         : %d
Workers           : %d
LogicalThreads    : %d
RAMBytes          : %d
PagefileBytes     : %d
EmbeddedSourceSHA : %s
`, version, inv.Root, cfg.Mode, cfg.MaxPly, cfg.MinPly, cfg.MinElo, cfg.MaxEloGap, cfg.Workers, hw.LogicalThreads, hw.RAMBytes, hw.PagefileBytes, embeddedSourceSHA256())
	return os.WriteFile(path, []byte(text), 0644)
}

func writeSources(path string, inv Inventory) error {
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - broninventaris\nRoot: %s\n\n", version, inv.Root)
	for i, s := range inv.Sources {
		fmt.Fprintf(&b, "%03d | %-4s | %d bytes | complete=%v | %s\n", i+1, s.Kind, s.Bytes, s.Complete, s.Path)
		for _, a := range s.Aux {
			fmt.Fprintf(&b, "      aux: %s\n", a)
		}
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeChecksums(path, runDir string) error {
	var files []string
	err := filepath.Walk(runDir, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || filepath.Clean(p) == filepath.Clean(path) {
			return nil
		}
		files = append(files, p)
		return nil
	})
	if err != nil {
		return err
	}
	sort.Strings(files)
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - SHA-256\n\n", version)
	for _, p := range files {
		h, err := fileSHA256(p)
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(runDir, p)
		fmt.Fprintf(&b, "%s  %s\n", h, rel)
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeMetalStatus(metalDir string, inv Inventory) error {
	text := fmt.Sprintf(`Source2Metal v%s - METAL beta status

Huidige adapterlaag:
- CTG -> METAL gebruikt de geïntegreerde Ctg2Metal v2.1.0-lijn.
- PGN/CBH/2CBH leveren in deze beta RAW_GAMES; zij voeden nog niet rechtstreeks
  één gezamenlijke position-centric METAL Evidence Engine.

Gepland vervolg:
- GAME evidence uit PGN/CBH/2CBH
- afzonderlijk BOOK evidence uit CTG
- transpositie-bewuste PositionKey
- confidence / Elo-correctie / bronherkomst
- Fritz Learning Encoder als afzonderlijke laag
`, version)
	return os.WriteFile(filepath.Join(metalDir, "METAL_BETA_STATUS.txt"), []byte(text), 0644)
}
