# Source2Metal V2 — beta-specificatie

Versie: **2.1.0-beta1**

## Hoofddoel
Eén versieerbare Source2Metal-pijplijn waarin bronherkenning, RAW en METAL
samenleven en waarin de gebruikte historische broncode letterlijk wordt bewaard.
RAW blijft het fundament; METAL blijft een afzonderlijke, toetsbare leerlaag.

## Bronnen
Recursief vanaf de EXE-map, nooit erboven:
- PGN — inhoudelijk actief
- CTG + CTO + CTB — inhoudelijk actief vanaf deze beta
- CBH — herkenning actief, importer nog open
- 2CBH — herkenning actief, importer nog open

Uitvoermappen (`!Source2Metal_Output`, `*_output`) en tijdelijke mappen worden
niet opnieuw als bron gelezen.

## RAW
### RAW_GAMES
Echte partijen uit PGN (later ook CBH/2CBH). Beta3-pijplijn blijft behouden:
parallelle worker-pool, hoofdvariant, commentaren/varianten verwijderd, exacte
partijduplicaten verwijderd, max ply/min ply/Elo/Elo-gap instelbaar.

### RAW_BOOKS
CTG-boom -> neutrale representatieve PGN via de geïntegreerde CTGExtractor v2.4
lijn. Donor recommendation/Fact wordt niet als sterktesignaal overgenomen.

### RAW_COMBINED
Alleen als zowel GAMES als BOOKS bestaan. Streaming concatenatie. Geen
cross-class deduplicatie omdat echte partijen en boeklijnen verschillende
bewijssoorten zijn.

## METAL
CTG -> Source2Metal_METAL.pgn via geïntegreerde Ctg2Metal v2.1.0-logica.
Dit is een tijdelijke adapterlaag totdat de algemene Source2Metal Evidence Engine
alle bronsoorten position-centric kan combineren.

Gecorrigeerde Fritz-inleerinstelling:
- Overwinningen AAN
- Verliespartijen AAN
- Wit UIT
- Zwart UIT
- Speler UIT
- spelernaam leeg
- alle partijen

## Parallelle verwerking
Per pc hardwaredetectie; standaard 50% van gedetecteerde logische CPU-threads.
PGN gebruikt werkelijk een worker-pool. CTG gebruikt in deze eerste integratie
nog de threading/streaming-eigenschappen van de historische modules zelf.

## Uitvoer
```
!Source2Metal_Output/<timestamp>/
  RAW/
    GAMES/Source2Metal_RAW_GAMES.pgn
    BOOKS/<book>/Source2Metal_RAW_BOOKS.pgn
    COMBINED/Source2Metal_RAW_COMBINED.pgn
  METAL/<book>/Source2Metal_METAL.pgn
  REPORT/
  TEMP/   (na succes verwijderd)
```
Lege resultaatmappen worden niet bewust behouden.

## Bronbehoud
De release-source bevat:
- actuele Source2Metal-code;
- aangepaste interne CTG-adapters;
- exacte originele bronbestanden onder `legacy_sources/`;
- vorige beta3 sourcearchive;
- build- en extractie-informatie.
Dezelfde sourcearchive wordt in de EXE ingebed en is via `-extract-source`
terug te halen.

## Open vervolgpunten
- praktische CTG-regressietest op Fritz20.ctg;
- RAW_BOOKS in ChessBase/Fritz valideren;
- METAL-output en leerimpact valideren;
- volledige PGN-legaliteitsvalidator uit Pgn2Metal integreren;
- CBH-importer;
- 2CBH-importer;
- algemene position-centric Evidence Engine;
- hervatbare/checkpoint-runs.
