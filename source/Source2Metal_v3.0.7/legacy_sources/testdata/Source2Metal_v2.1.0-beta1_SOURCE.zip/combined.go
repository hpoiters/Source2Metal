package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir() && st.Size() > 0
}

func buildCombined(rawGames string, rawBooks []string, layout OutputLayout, c *Counters) (string, error) {
	if !fileExists(rawGames) || len(rawBooks) == 0 {
		return "", nil
	}
	if err := os.MkdirAll(layout.RawCombinedDir, 0755); err != nil {
		return "", err
	}
	out := filepath.Join(layout.RawCombinedDir, "Source2Metal_RAW_COMBINED.pgn")
	f, err := os.Create(out)
	if err != nil {
		return "", err
	}
	bw := bufio.NewWriterSize(f, 8<<20)
	appendOne := func(path string) error {
		in, err := os.Open(path)
		if err != nil {
			return err
		}
		_, cpErr := io.Copy(bw, in)
		_ = in.Close()
		if cpErr != nil {
			return cpErr
		}
		_, err = bw.WriteString("\n\n")
		return err
	}
	fmt.Println("COMBINED: RAW_GAMES + RAW_BOOKS samenvoegen (streaming; geen cross-class deduplicatie).")
	if err := appendOne(rawGames); err != nil {
		_ = f.Close()
		return "", err
	}
	for _, p := range rawBooks {
		if fileExists(p) {
			if err := appendOne(p); err != nil {
				_ = f.Close()
				return "", err
			}
		}
	}
	if err := bw.Flush(); err != nil {
		_ = f.Close()
		return "", err
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	st, err := os.Stat(out)
	if err != nil {
		return "", err
	}
	sha, err := fileSHA256(out)
	if err != nil {
		return "", err
	}
	c.CombinedBytes = st.Size()
	c.CombinedSHA256 = sha
	return out, nil
}
