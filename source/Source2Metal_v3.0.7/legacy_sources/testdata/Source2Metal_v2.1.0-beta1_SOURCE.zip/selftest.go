package main

import (
	"os"
	"path/filepath"

	"source2metal/internal/ctgmetal"
	"source2metal/internal/ctgraw"
)

func selfTest() error {
	tmp, err := os.MkdirTemp("", "s2m-selftest-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(tmp)
	pgn := `[Event "T"]
[White "A"]
[Black "B"]
[WhiteElo "2600"]
[BlackElo "2600"]
[Result "1-0"]

1. e4 {x} e5 (1... c5 2. Nf3) 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 1-0
`
	if err := os.WriteFile(filepath.Join(tmp, "x.pgn"), []byte(pgn), 0644); err != nil {
		return err
	}
	inv, err := scanSources(tmp)
	if err != nil {
		return err
	}
	out := filepath.Join(tmp, "!Source2Metal_Output", "test", "RAW", "GAMES", "Source2Metal_RAW_GAMES.pgn")
	c := Counters{}
	cfg := Config{MaxPly: 12, MinPly: 4, Workers: 2}
	path, err := buildRawGames(inv, out, cfg, &c)
	if err != nil {
		return err
	}
	if c.GamesAccepted != 1 {
		return os.ErrInvalid
	}
	if _, err := os.Stat(path); err != nil {
		return err
	}
	if err := ctgraw.SelfTest(); err != nil {
		return err
	}
	if err := ctgmetal.SelfTest(); err != nil {
		return err
	}
	return nil
}
