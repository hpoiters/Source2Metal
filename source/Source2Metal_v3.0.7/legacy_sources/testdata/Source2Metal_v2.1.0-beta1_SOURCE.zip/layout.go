package main

import (
	"os"
	"path/filepath"
)

func createLayout(root, stamp string) (OutputLayout, error) {
	run := filepath.Join(root, "!Source2Metal_Output", stamp)
	l := OutputLayout{
		RunDir:         run,
		RawDir:         filepath.Join(run, "RAW"),
		RawGamesDir:    filepath.Join(run, "RAW", "GAMES"),
		RawBooksDir:    filepath.Join(run, "RAW", "BOOKS"),
		RawCombinedDir: filepath.Join(run, "RAW", "COMBINED"),
		MetalDir:       filepath.Join(run, "METAL"),
		ReportDir:      filepath.Join(run, "REPORT"),
		TempDir:        filepath.Join(run, "TEMP"),
	}
	l.RawGamesFile = filepath.Join(l.RawGamesDir, "Source2Metal_RAW_GAMES.pgn")
	// Alleen de run-, REPORT- en TEMP-map worden vooraf gemaakt. RAW/BOOKS,
	// RAW/COMBINED en METAL verschijnen pas als er werkelijk output is.
	for _, d := range []string{l.RunDir, l.ReportDir, l.TempDir} {
		if err := os.MkdirAll(d, 0755); err != nil {
			return OutputLayout{}, err
		}
	}
	return l, nil
}

func pruneEmptyOutputDirs(l OutputLayout) {
	// Bottom-up; alleen lege Source2Metal-uitvoermappen worden verwijderd.
	for _, d := range []string{l.RawGamesDir, l.RawBooksDir, l.RawCombinedDir, l.MetalDir, l.RawDir} {
		ents, err := os.ReadDir(d)
		if err == nil && len(ents) == 0 {
			_ = os.Remove(d)
		}
	}
}
