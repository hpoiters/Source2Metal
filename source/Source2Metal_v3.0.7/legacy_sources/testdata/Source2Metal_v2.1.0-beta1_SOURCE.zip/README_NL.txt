Source2Metal v2.1.0-beta1
=========================

DOEL
Source2Metal wordt één gezamenlijke pijplijn voor RAW en METAL. Deze beta is
bewust een integratiebeta: het skelet moet nu compleet genoeg worden om de
belangrijkste historische broncode niet opnieuw kwijt te raken. Inhoudelijke
perfectie van de CTG-uitvoer is nog géén claim; juist daarvoor is deze beta om
te testen.

WAT DEZE BETA WERKELIJK DOET
- Recursieve broninventarisatie vanaf de EXE-map, nooit erboven.
- Herkent PGN, complete CTG/CTO/CTB-sets, CBH en 2CBH.
- Slaat !Source2Metal_Output, *_output, TEMP/tijdelijk en eigen uitvoer over.
- PGN -> RAW/GAMES via de in beta3 praktisch gevalideerde parallelle pijplijn.
- CTG -> RAW/BOOKS via de bewaarde CTGExtractor v2.4-lijn.
- CTG -> METAL via de bewaarde Ctg2Metal v2.1.0-lijn.
- Als zowel RAW_GAMES als RAW_BOOKS bestaan, wordt RAW_COMBINED streaming
  opgebouwd. GAME- en BOOK-RAW worden daarbij bewust niet als één statistische
  klasse ontdubbeld.
- CBH en 2CBH worden nog alleen herkend/gerapporteerd.
- Hardwaredetectie en standaard 50% van de logische CPU-threads blijven actief.
- Pagefile/RAM/vrije-ruimte informatie blijft actief waar Windows dit levert.
- Rustige voortgangsbalk voor PGN; de historische CTG-modules tonen hun eigen
  voortgang/diagnostiek tijdens deze eerste integratiebeta.
- Alleen outputmappen waarvoor werkelijk uitvoer bestaat blijven na afloop staan.
- EXE bevat een bronarchive; -extract-source haalt hem terug.

UITVOER
!Source2Metal_Output/<tijdstempel>/
  RAW/
    GAMES/Source2Metal_RAW_GAMES.pgn
    BOOKS/<boek>/Source2Metal_RAW_BOOKS.pgn
    COMBINED/Source2Metal_RAW_COMBINED.pgn   (alleen als GAMES + BOOKS bestaan)
  METAL/<boek>/
    Source2Metal_METAL.pgn                   (alleen als selectie slaagt)
    Ctg2Metal_report.txt
    INSTRUCTIE_INLEREN.txt
  REPORT/
    Source2Metal_Report.txt
    Source2Metal_Settings.txt
    Source2Metal_Sources.txt
    Source2Metal_BuildInfo.txt
    Source2Metal_SourceExtract.txt
    Source2Metal_SHA256.txt
    STATUS_KLAAR.txt

AANBEVOLEN EERSTE TEST
Voor de huidige regressietest kan interactief voorlopig overal Enter worden
gebruikt:
  workers   = 50% van gedetecteerde logische threads
  modus     = 3 (RAW + METAL)
  max ply   = 100
  min ply   = 24
  Elo       = bronselectie behouden
  Elo-gap   = geen

LET OP BIJ CTG
RAW_BOOKS is representatieve, neutrale PGN-uitvoer uit de CTG-boom. Het is geen
historische partijendatabase. METAL gebruikt de oude Ctg2Metal-selectielogica.
Deze twee sporen zijn bewust apart gehouden.

FRITZ - GECORRIGEERDE INLEERINSTELLING VOOR METAL
Bij "Leren van database" / "Bijleren uit database":
  Overwinningen   AAN
  Verliespartijen AAN
  Wit             UIT
  Zwart           UIT
  Speler          UIT
  Spelernaam      LEEG
  Partijen        ALLE
Deze regel vervangt oudere Ctg2Metal-documentatie waarin nog "alle filters UIT"
stond.

BRONCODEBEWARING
De SOURCE-archive bevat niet alleen de geïntegreerde Source2Metal-code maar ook
exacte kopieën van de twee aangeleverde historische CTG-bronnen en de vorige
Source2Metal beta3-sourcearchive onder legacy_sources/.

Bron uit EXE halen:
  Source2Metal_v2.1.0-beta1.exe -extract-source

Build-info:
  Source2Metal_v2.1.0-beta1.exe -build-info

Pagefile-uitleg:
  Source2Metal_v2.1.0-beta1.exe -pagefile-help

BETASTATUS
- PGN/RAW is reeds praktisch getest in beta3.
- CTG/RAW_BOOKS en CTG/METAL zijn nu voor het eerst in dezelfde EXE geïmplanteerd.
- CBH/2CBH-import en de latere gezamenlijke position-centric Evidence Engine
  moeten nog volgen.

LICENTIE
GPL v3 of later voor Source2Metal als geheel; zie LICENSE_GPL-3.0.txt en
THIRD_PARTY_NOTICES.txt.
