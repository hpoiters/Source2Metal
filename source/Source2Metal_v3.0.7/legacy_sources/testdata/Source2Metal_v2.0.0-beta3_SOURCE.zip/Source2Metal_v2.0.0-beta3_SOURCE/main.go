package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

var stdin = bufio.NewReader(os.Stdin)

func main() {
	cfg, err := parseConfig()
	if err != nil {
		fatal(cfg, err)
		return
	}
	if cfg.ExtractSource {
		p, err := extractEmbeddedSource()
		if err != nil {
			fatal(cfg, err)
			return
		}
		fmt.Println("Broncode uit EXE geëxtraheerd:", p)
		fmt.Println("SHA-256:", embeddedSourceSHA256())
		return
	}
	if cfg.BuildInfo {
		fmt.Print(buildInfoText())
		return
	}
	if cfg.PagefileHelp {
		fmt.Println(pagefileHelpText())
		return
	}
	if cfg.SelfTest {
		if err := selfTest(); err != nil {
			fatal(cfg, err)
			return
		}
		fmt.Println("Source2Metal selftest: OK")
		return
	}
	if err := run(cfg); err != nil {
		fatal(cfg, err)
		return
	}
	if !cfg.NoPause && cfg.Interactive {
		pause()
	}
}

func parseConfig() (Config, error) {
	c := Config{Mode: "", MaxPly: defaultMaxPly, MinPly: defaultMinPly}
	flag.StringVar(&c.Input, "input", "", "invoermap; standaard map van exe")
	flag.StringVar(&c.Mode, "mode", "", "inventory|raw|all")
	flag.IntVar(&c.MaxPly, "max-ply", defaultMaxPly, "maximale RAW-diepte 1..120")
	flag.IntVar(&c.MinPly, "min-ply", defaultMinPly, "minimum partij-lengte")
	flag.IntVar(&c.MinElo, "min-elo", 0, "0 of minimum Elo voor beide spelers")
	flag.IntVar(&c.MaxEloGap, "max-elo-gap", 0, "0=uit")
	flag.IntVar(&c.Workers, "workers", 0, "0=automatisch (50% logische threads)")
	flag.BoolVar(&c.NoPause, "no-pause", false, "niet pauzeren")
	flag.BoolVar(&c.SelfTest, "selftest", false, "interne test")
	flag.BoolVar(&c.ExtractSource, "extract-source", false, "extraheer ingebedde broncode naast de exe")
	flag.BoolVar(&c.BuildInfo, "build-info", false, "toon build- en bronextractie-informatie")
	flag.BoolVar(&c.PagefileHelp, "pagefile-help", false, "toon Windows-pagefile advies")
	flag.Parse()
	c.Interactive = len(os.Args) == 1
	if c.Input == "" {
		exe, err := os.Executable()
		if err != nil {
			return c, err
		}
		c.Input = filepath.Dir(exe)
	}
	if c.MaxPly < 1 || c.MaxPly > maxAllowedPly {
		return c, fmt.Errorf("max-ply moet 1..%d zijn", maxAllowedPly)
	}
	if c.MinPly < 1 || c.MinPly > maxAllowedPly {
		return c, fmt.Errorf("min-ply moet 1..%d zijn", maxAllowedPly)
	}
	return c, nil
}

func run(cfg Config) error {
	root, err := filepath.Abs(cfg.Input)
	if err != nil {
		return err
	}
	hw := detectHardware(root)
	if cfg.Workers <= 0 {
		cfg.Workers = defaultWorkers(hw.LogicalThreads)
	}
	if cfg.Workers < 1 {
		cfg.Workers = 1
	}
	if cfg.Workers > hw.LogicalThreads {
		cfg.Workers = hw.LogicalThreads
	}

	fmt.Printf("Source2Metal v%s BETA\n", version)
	fmt.Printf("Platform         : %s/%s\n", runtime.GOOS, runtime.GOARCH)
	fmt.Printf("Werkmap          : %s\n", root)
	printHardware(hw)

	fmt.Println("\n1/6 Bronnen inventariseren...")
	inv, err := scanSources(root)
	if err != nil {
		return err
	}
	printInventory(inv)
	if cfg.Interactive {
		cfg, err = interactiveChoices(cfg, inv, hw)
		if err != nil {
			return err
		}
	}
	if cfg.Mode == "" {
		cfg.Mode = "inventory"
	}

	stamp := time.Now().Format("2006-01-02_15-04-05")
	layout, err := createLayout(root, stamp)
	if err != nil {
		return err
	}
	started := time.Now()
	c := Counters{Started: started}
	for _, s := range inv.Sources {
		switch s.Kind {
		case KindPGN:
			c.FilesPGN++
		case KindCTG:
			c.SetsCTG++
		case KindCBH:
			c.FilesCBH++
		case Kind2CBH:
			c.Files2CBH++
		}
	}

	fmt.Println("\n2/6 Bronnen valideren...")
	fmt.Println("Bronsets geïnventariseerd; onvolledige CTG-sets blijven gemarkeerd en worden niet als complete set behandeld.")

	if cfg.Mode == "raw" || cfg.Mode == "all" {
		fmt.Println("\n3/6 RAW bouwen...")
		raw, err := buildRawGames(inv, layout.RawGamesFile, cfg, &c)
		if err != nil {
			c.Elapsed = time.Since(started)
			_ = writeReports(layout, inv, cfg, hw, c, "ONVOLLEDIG")
			return err
		}
		fmt.Println("RAW gemaakt:", raw)
	} else {
		fmt.Println("\n3/6 RAW bouwen: overgeslagen")
	}

	if cfg.Mode == "all" {
		fmt.Println("\n4/6 METAL bouwen...")
		if err := writeMetalStatus(layout.MetalDir, inv); err != nil {
			return err
		}
		fmt.Println("METAL-proeflaag: status geschreven; Evidence Engine nog bewust niet actief.")
	} else {
		fmt.Println("\n4/6 METAL bouwen: overgeslagen")
	}

	fmt.Println("\n5/6 Rapporten + checksums...")
	c.Elapsed = time.Since(started)
	if err := writeReports(layout, inv, cfg, hw, c, "KLAAR"); err != nil {
		return err
	}

	fmt.Println("\n6/6 Tijdelijke bestanden opruimen...")
	_ = os.RemoveAll(layout.TempDir)
	fmt.Println("TEMP opgeruimd.")

	fmt.Println("\nKlaar. Resultaten:", layout.RunDir)
	fmt.Printf("Workers gebruikt: %d / %d logische threads\n", cfg.Workers, hw.LogicalThreads)
	fmt.Println("Bronextractie uit deze EXE: start met -extract-source")
	if cfg.Mode == "all" {
		fmt.Println("METAL: beta3 schrijft nog geen Metal.pgn; de ongeteste leerencoder blijft bewust uit.")
	}
	return nil
}

func interactiveChoices(c Config, inv Inventory, hw HardwareInfo) (Config, error) {
	fmt.Println("\nPARALLELLE VERWERKING")
	def := defaultWorkers(hw.LogicalThreads)
	fmt.Printf("Logische CPU-threads : %d\n", hw.LogicalThreads)
	fmt.Printf("Aanbevolen workers   : %d (50%%)\n", def)
	c.Workers = askInt(fmt.Sprintf("Aantal workers [1-%d] (Enter = %d): ", hw.LogicalThreads, def), def, 1, hw.LogicalThreads)

	fmt.Println("\nMODUS")
	fmt.Println("  1 = alleen inventaris/rapport")
	fmt.Println("  2 = RAW_GAMES bouwen uit alle gevonden PGN-bronnen")
	fmt.Println("  3 = RAW + METAL-proefmodel (METAL nog alleen architectuurstatus)")
	fmt.Print("Keuze [1-3] (Enter = 3): ")
	s, _ := stdin.ReadString('\n')
	s = strings.TrimSpace(s)
	if s == "" {
		s = "3"
	}
	switch s {
	case "1":
		c.Mode = "inventory"
	case "2":
		c.Mode = "raw"
	case "3":
		c.Mode = "all"
	default:
		return c, errors.New("ongeldige modus")
	}
	if c.Mode != "inventory" {
		c.MaxPly = askInt(fmt.Sprintf("Maximale RAW-diepte [1-%d] (Enter = %d): ", maxAllowedPly, defaultMaxPly), defaultMaxPly, 1, maxAllowedPly)
		c.MinPly = askInt(fmt.Sprintf("Minimumlengte partij [1-%d] (Enter = %d): ", maxAllowedPly, defaultMinPly), defaultMinPly, 1, maxAllowedPly)
		fmt.Println("Extra Elo-filter: 0=bronselectie behouden, 1=beide >=2500, 2=beide >=2400")
		e := askInt("Keuze [0-2] (Enter = 0): ", 0, 0, 2)
		if e == 1 {
			c.MinElo = 2500
		} else if e == 2 {
			c.MinElo = 2400
		} else {
			c.MinElo = 0
		}
		c.MaxEloGap = askInt("Maximaal Elo-verschil (0=geen, Enter=0): ", 0, 0, 2000)
	}
	return c, nil
}

func askInt(prompt string, def, min, max int) int {
	for {
		fmt.Print(prompt)
		s, _ := stdin.ReadString('\n')
		s = strings.TrimSpace(s)
		if s == "" {
			return def
		}
		n, e := strconv.Atoi(s)
		if e == nil && n >= min && n <= max {
			return n
		}
		fmt.Println("Ongeldige invoer.")
	}
}

func fatal(c Config, err error) {
	fmt.Fprintln(os.Stderr, "\nFOUT:", err)
	if !c.NoPause && c.Interactive {
		pause()
	}
	os.Exit(2)
}

func pause() {
	fmt.Print("\nDruk op Enter om af te sluiten...")
	_, _ = stdin.ReadString('\n')
}
