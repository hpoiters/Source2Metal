package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

func writeReports(layout OutputLayout, inv Inventory, cfg Config, hw HardwareInfo, c Counters, status string) error {
	if err := os.MkdirAll(layout.ReportDir, 0755); err != nil {
		return err
	}
	if err := writeInventoryReport(filepath.Join(layout.ReportDir, "Source2Metal_Report.txt"), inv, cfg, hw, c, status); err != nil {
		return err
	}
	if err := writeSettings(filepath.Join(layout.ReportDir, "Source2Metal_Settings.txt"), inv, cfg, hw); err != nil {
		return err
	}
	if err := writeSources(filepath.Join(layout.ReportDir, "Source2Metal_Sources.txt"), inv); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "Source2Metal_BuildInfo.txt"), []byte(buildInfoText()), 0644); err != nil {
		return err
	}
	extractInfo := fmt.Sprintf(`Source2Metal v%s - bronextractie uit de EXE

De Windows-EXE bevat een ingebedde bronarchive van deze release.

Gebruik in een opdrachtprompt in dezelfde map:
  Source2Metal_v%s.exe -extract-source

De EXE schrijft dan naast zichzelf:
  Source2Metal_v%s_EXTRACTED_SOURCE.zip

Ingebedde bron SHA-256:
  %s

Build-info bekijken zonder een run te starten:
  Source2Metal_v%s.exe -build-info

Pagefile-instructie bekijken:
  Source2Metal_v%s.exe -pagefile-help
`, version, version, version, embeddedSourceSHA256(), version, version)
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "Source2Metal_SourceExtract.txt"), []byte(extractInfo), 0644); err != nil {
		return err
	}
	statusText := fmt.Sprintf("Source2Metal v%s\nStatus: %s\nModus: %s\nWorkers: %d/%d\nRAW partijen: %d\nVerstreken: %s\n", version, status, cfg.Mode, cfg.Workers, hw.LogicalThreads, c.GamesAccepted, c.Elapsed)
	if err := os.WriteFile(filepath.Join(layout.ReportDir, "STATUS_"+status+".txt"), []byte(statusText), 0644); err != nil {
		return err
	}
	return writeChecksums(filepath.Join(layout.ReportDir, "Source2Metal_SHA256.txt"), layout.RunDir)
}

func writeInventoryReport(path string, inv Inventory, cfg Config, hw HardwareInfo, c Counters, status string) error {
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - BETA RAPPORT\n\n", version)
	fmt.Fprintf(&b, "Status            : %s\n", status)
	fmt.Fprintf(&b, "Root              : %s\n", inv.Root)
	fmt.Fprintf(&b, "Modus             : %s\n", cfg.Mode)
	fmt.Fprintf(&b, "Workers           : %d / %d logische threads\n", cfg.Workers, hw.LogicalThreads)
	if hw.CPUName != "" {
		fmt.Fprintf(&b, "CPU               : %s\n", hw.CPUName)
	}
	if hw.RAMKnown {
		fmt.Fprintf(&b, "RAM               : %.1f GB\n", gib(hw.RAMBytes))
	}
	if hw.PagefileKnown {
		fmt.Fprintf(&b, "Pagefile          : %.1f GB", gib(hw.PagefileBytes))
		if hw.PagefilePaths != "" {
			fmt.Fprintf(&b, " | %s", hw.PagefilePaths)
		}
		fmt.Fprintln(&b)
	}
	if hw.FreeKnown {
		fmt.Fprintf(&b, "Vrij bij start    : %.1f GB\n", gib(hw.FreeBytes))
	}
	fmt.Fprintf(&b, "Max diepte        : %d ply\n", cfg.MaxPly)
	fmt.Fprintf(&b, "Minimum partij    : %d ply\n", cfg.MinPly)
	if cfg.MinElo == 0 {
		fmt.Fprintln(&b, "Elo-filter        : bronselectie behouden")
	} else {
		fmt.Fprintf(&b, "Elo-filter        : beide spelers >= %d\n", cfg.MinElo)
	}
	if cfg.MaxEloGap == 0 {
		fmt.Fprintln(&b, "Max Elo-verschil : geen")
	} else {
		fmt.Fprintf(&b, "Max Elo-verschil : %d\n", cfg.MaxEloGap)
	}
	fmt.Fprintf(&b, "Verstreken        : %s\n", c.Elapsed)
	fmt.Fprintf(&b, "Embedded source   : %s\n", embeddedSourceSHA256())

	fmt.Fprintln(&b, "\nBRONNEN")
	for _, s := range inv.Sources {
		status := ""
		if s.Kind == KindCTG && !s.Complete {
			status = " | ONVOLLEDIG"
		}
		fmt.Fprintf(&b, "%-4s | %s%s\n", s.Kind, s.Path, status)
	}
	fmt.Fprintln(&b, "\nRAW_GAMES")
	fmt.Fprintf(&b, "Partijen gezien      : %s\n", fmtInt(c.GamesSeen))
	fmt.Fprintf(&b, "Geaccepteerd         : %s\n", fmtInt(c.GamesAccepted))
	fmt.Fprintf(&b, "Exact duplicaat      : %s\n", fmtInt(c.GamesDuplicate))
	fmt.Fprintf(&b, "Geen geldige uitslag : %s\n", fmtInt(c.GamesNoResult))
	fmt.Fprintf(&b, "FEN/SetUp            : %s\n", fmtInt(c.GamesSetup))
	fmt.Fprintf(&b, "Te kort              : %s\n", fmtInt(c.GamesShort))
	fmt.Fprintf(&b, "Elo-filter           : %s\n", fmtInt(c.GamesElo))
	fmt.Fprintf(&b, "Elo-verschil         : %s\n", fmtInt(c.GamesEloGap))
	fmt.Fprintf(&b, "Variatietakken weg   : %s\n", fmtInt(c.VariationsStripped))
	fmt.Fprintf(&b, "Commentaren weg      : %s\n", fmtInt(c.CommentsStripped))
	fmt.Fprintf(&b, "Ply geschreven       : %s\n", fmtInt(c.PlyWritten))
	if c.OutputBytes > 0 {
		fmt.Fprintf(&b, "RAW bytes            : %d\nRAW SHA-256          : %s\n", c.OutputBytes, c.OutputSHA256)
	}
	fmt.Fprintln(&b, "\nBETA3-BEPERKINGEN")
	fmt.Fprintln(&b, "- PGN -> RAW_GAMES gebruikt nu echte parallelle worker-verwerking, maar nog geen volledige legale schaakbordvalidator.")
	fmt.Fprintln(&b, "- CBH en 2CBH worden herkend en gerapporteerd, nog niet inhoudelijk uitgelezen.")
	fmt.Fprintln(&b, "- CTG-sets worden herkend en op .ctg/.cto/.ctb-compleetheid gecontroleerd, RAW_BOOKS is nog niet gekoppeld.")
	fmt.Fprintln(&b, "- METAL Evidence Engine en Fritz Learning Encoder zijn nog niet actief; beta3 maakt dus nog geen Metal.pgn.")
	fmt.Fprintln(&b, "- RAW/BOOKS en RAW/COMBINED zijn alvast als aparte uitvoermappen aanwezig voor volgende integratiestappen.")
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeSettings(path string, inv Inventory, cfg Config, hw HardwareInfo) error {
	text := fmt.Sprintf(`Source2Metal v%s - instellingen

Root              : %s
Mode              : %s
MaxPly            : %d
MinPly            : %d
MinElo            : %d
MaxEloGap         : %d
Workers           : %d
LogicalThreads    : %d
RAMBytes          : %d
PagefileBytes     : %d
EmbeddedSourceSHA : %s
`, version, inv.Root, cfg.Mode, cfg.MaxPly, cfg.MinPly, cfg.MinElo, cfg.MaxEloGap, cfg.Workers, hw.LogicalThreads, hw.RAMBytes, hw.PagefileBytes, embeddedSourceSHA256())
	return os.WriteFile(path, []byte(text), 0644)
}

func writeSources(path string, inv Inventory) error {
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - broninventaris\nRoot: %s\n\n", version, inv.Root)
	for i, s := range inv.Sources {
		fmt.Fprintf(&b, "%03d | %-4s | %d bytes | complete=%v | %s\n", i+1, s.Kind, s.Bytes, s.Complete, s.Path)
		for _, a := range s.Aux {
			fmt.Fprintf(&b, "      aux: %s\n", a)
		}
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeChecksums(path, runDir string) error {
	var files []string
	err := filepath.Walk(runDir, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || filepath.Clean(p) == filepath.Clean(path) {
			return nil
		}
		files = append(files, p)
		return nil
	})
	if err != nil {
		return err
	}
	sort.Strings(files)
	var b strings.Builder
	fmt.Fprintf(&b, "Source2Metal v%s - SHA-256\n\n", version)
	for _, p := range files {
		h, err := fileSHA256(p)
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(runDir, p)
		fmt.Fprintf(&b, "%s  %s\n", h, rel)
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func writeMetalStatus(metalDir string, inv Inventory) error {
	text := fmt.Sprintf(`Source2Metal v%s - METAL beta status

De architectuur voor de METAL Evidence Engine is vastgelegd, maar beta3 maakt
bewust nog geen nieuwe Metal.pgn. Een ongeteste leerencoder zou een goed RAW-boek
kunnen beschadigen.

Geplande koppelingen:
- PGN/CBH/2CBH -> position-centric GAME evidence
- CTG -> afzonderlijk BOOK evidence
- transpositie-bewuste PositionKey
- sample confidence / Elo-correctie / bronherkomst
- Fritz Learning Encoder als afzonderlijke laag

De bestaande Pgn2Metal- en Ctg2Metal-bronlijnen blijven referentie voor de
volgende integratiestappen.
`, version)
	return os.WriteFile(filepath.Join(metalDir, "METAL_BETA_STATUS.txt"), []byte(text), 0644)
}
