# Source2Metal V2 — beta-specificatie

Versie: **2.0.0-beta3**

## Hoofddoel
Source2Metal vormt één overkoepelende pijplijn voor bronherkenning, RAW-opbouw
en later METAL-onderwijs. RAW is het fundament; METAL is een afzonderlijke,
controleerbare leerlaag die alleen bestaansrecht heeft als zij aantoonbaar
meerwaarde biedt.

## Bronnen
Recursieve herkenning vanaf de map van de EXE, nooit erboven:
- PGN
- CTG + CTO + CTB
- CBH-databaseset
- 2CBH

`*_output`, `!Source2Metal_Output`, temp/tijdelijk en eigen gegenereerde RAW/METAL
bestanden worden als bron uitgesloten.

## RAW
- RAW_GAMES: echte partijen uit PGN/CBH/2CBH.
- RAW_BOOKS: neutrale boeklijnen uit CTG.
- RAW_COMBINED: optionele combinatie van beide.
- Exacte partijen ontdubbelen; verschillende partijen met dezelfde opening
  blijven statistische waarnemingen.
- Hoofdvariant behouden, annotatievarianten niet uitwaaieren.

Beta3 bouwt alleen RAW_GAMES uit PGN.

## Parallelle verwerking
Hardware wordt per pc opnieuw gedetecteerd. Standaard gebruikt Source2Metal
50% van de gedetecteerde logische CPU-threads. De gebruiker kan dit aanpassen.
Beta3 gebruikt een echte worker-pool voor PGN-normalisatie/filtering/hashing en
één geordende aggregator/schrijver voor deterministische output en globale
deduplicatie.

## Hardware en geheugen
- logische CPU-threads altijd via runtime-detectie;
- Windows: CPU-naam, RAM, pagefile en vrije uitvoerruimte worden waar mogelijk
  via PowerShell/CIM uitgelezen;
- pagefile wordt nooit door Source2Metal gewijzigd;
- bij uitgeschakelde pagefile verschijnt een waarschuwing;
- `-pagefile-help` toont een korte Windows-instructie.

## Uitvoer per tijdstempel
```
!Source2Metal_Output/<timestamp>/
  RAW/
    GAMES/Source2Metal_RAW_GAMES.pgn
    BOOKS/
    COMBINED/
  METAL/
  REPORT/
    Source2Metal_Report.txt
    Source2Metal_Settings.txt
    Source2Metal_Sources.txt
    Source2Metal_BuildInfo.txt
    Source2Metal_SourceExtract.txt
    Source2Metal_SHA256.txt
    STATUS_KLAAR.txt
  TEMP/   (wordt na succesvolle run verwijderd)
```

## Voortgang
Beta3 toont tijdens PGN-verwerking één compacte, overschreven voortgangsregel met:
- voortgangsbalk + percentage;
- verwerkte partijen en RAW-partijen;
- workers;
- partijen per seconde;
- MB/s;
- verstreken tijd;
- ETA na korte stabilisatieperiode.

## Bronbewaring in de EXE
De EXE bevat `embedded_source.zip` via Go `//go:embed`.
- `-extract-source` schrijft deze archive naast de EXE terug;
- `-build-info` toont build- en SHA-256-informatie.

Dit is een extra vangrail naast de los meegeleverde SOURCE.zip.

## Nog open
- volledige legaliteitsvalidator uit de eerdere PGN-lijn integreren;
- native CTG-adapter koppelen aan RAW_BOOKS;
- betrouwbare CBH/2CBH-importer;
- RAW_COMBINED merge policy;
- position-centric METAL Evidence Engine;
- Fritz Learning Encoder en A/B/C-validatie tegen RAW en native Fritz leren;
- hervatbare runs/checkpoints.
