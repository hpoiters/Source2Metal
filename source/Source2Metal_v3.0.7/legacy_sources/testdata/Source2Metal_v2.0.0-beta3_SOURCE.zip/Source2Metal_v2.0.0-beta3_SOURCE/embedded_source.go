package main

import (
	"crypto/sha256"
	_ "embed"
	"fmt"
	"os"
	"path/filepath"
)

//go:embed embedded_source.zip
var embeddedSourceZip []byte

func embeddedSourceSHA256() string {
	h := sha256.Sum256(embeddedSourceZip)
	return fmt.Sprintf("%x", h[:])
}

func extractEmbeddedSource() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	out := filepath.Join(filepath.Dir(exe), "Source2Metal_v"+version+"_EXTRACTED_SOURCE.zip")
	if err := os.WriteFile(out, embeddedSourceZip, 0644); err != nil {
		return "", err
	}
	return out, nil
}

func buildInfoText() string {
	return fmt.Sprintf(`Source2Metal v%s
Build date UTC       : %s
Embedded source bytes: %d
Embedded source SHA256: %s

Bronextractie uit de EXE:
  Source2Metal_v%s.exe -extract-source

Daarmee schrijft de EXE naast zichzelf:
  Source2Metal_v%s_EXTRACTED_SOURCE.zip

Deze archive bevat de bron- en documentatiebestanden die in deze release zijn
ingebed. Controleer desgewenst de SHA-256 met de waarde hierboven.
`, version, buildDateUTC, len(embeddedSourceZip), embeddedSourceSHA256(), version, version)
}
