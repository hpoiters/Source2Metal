package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
)

func defaultWorkers(threads int) int {
	if threads <= 1 {
		return 1
	}
	w := threads / 2
	if w < 1 {
		w = 1
	}
	return w
}

func detectHardware(root string) HardwareInfo {
	h := HardwareInfo{LogicalThreads: runtime.NumCPU()}
	if h.LogicalThreads < 1 {
		h.LogicalThreads = 1
	}
	if runtime.GOOS == "windows" {
		detectWindowsHardware(root, &h)
	} else {
		detectUnixLikeHardware(root, &h)
	}
	return h
}

func detectWindowsHardware(root string, h *HardwareInfo) {
	drive := filepath.VolumeName(root)
	if drive == "" {
		drive = "C:"
	}
	letter := strings.TrimSuffix(drive, ":")
	ps := fmt.Sprintf(`$ErrorActionPreference='SilentlyContinue';
$cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name);
$ram=[int64](Get-CimInstance Win32_ComputerSystem | Select-Object -ExpandProperty TotalPhysicalMemory);
$pf=Get-CimInstance Win32_PageFileUsage;
$pfmb=[int64](($pf | Measure-Object -Property AllocatedBaseSize -Sum).Sum);
$pfpaths=($pf | ForEach-Object {$_.Name}) -join ';';
$drv=Get-PSDrive -Name '%s';
$free=[int64]$drv.Free;
'CPU='+$cpu; 'RAM_BYTES='+$ram; 'PAGEFILE_MB='+$pfmb; 'PAGEFILE_PATHS='+$pfpaths; 'FREE_BYTES='+$free;`, letter)
	cmd := exec.Command("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps)
	out, err := cmd.Output()
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "=") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		key, val := parts[0], strings.TrimSpace(parts[1])
		switch key {
		case "CPU":
			h.CPUName = val
		case "RAM_BYTES":
			if n, e := strconv.ParseInt(val, 10, 64); e == nil && n > 0 {
				h.RAMBytes, h.RAMKnown = n, true
			}
		case "PAGEFILE_MB":
			if n, e := strconv.ParseInt(val, 10, 64); e == nil {
				h.PagefileBytes, h.PagefileKnown = n*1024*1024, true
			}
		case "PAGEFILE_PATHS":
			h.PagefilePaths = val
		case "FREE_BYTES":
			if n, e := strconv.ParseInt(val, 10, 64); e == nil && n >= 0 {
				h.FreeBytes, h.FreeKnown = n, true
			}
		}
	}
}

func detectUnixLikeHardware(root string, h *HardwareInfo) {
	if f, err := os.Open("/proc/cpuinfo"); err == nil {
		s := bufio.NewScanner(f)
		for s.Scan() {
			line := s.Text()
			if strings.HasPrefix(line, "model name") {
				if p := strings.SplitN(line, ":", 2); len(p) == 2 {
					h.CPUName = strings.TrimSpace(p[1])
					break
				}
			}
		}
		_ = f.Close()
	}
	if f, err := os.Open("/proc/meminfo"); err == nil {
		s := bufio.NewScanner(f)
		for s.Scan() {
			fields := strings.Fields(s.Text())
			if len(fields) < 2 {
				continue
			}
			n, _ := strconv.ParseInt(fields[1], 10, 64)
			switch strings.TrimSuffix(fields[0], ":") {
			case "MemTotal":
				h.RAMBytes, h.RAMKnown = n*1024, true
			case "SwapTotal":
				h.PagefileBytes, h.PagefileKnown = n*1024, true
			}
		}
		_ = f.Close()
	}
}

func printHardware(h HardwareInfo) {
	fmt.Println("\nHARDWAREDETECTIE")
	if h.CPUName != "" {
		fmt.Println("CPU              :", h.CPUName)
	}
	fmt.Printf("Logische threads : %d\n", h.LogicalThreads)
	if h.RAMKnown {
		fmt.Printf("RAM              : %.1f GB\n", gib(h.RAMBytes))
	} else {
		fmt.Println("RAM              : niet betrouwbaar uitgelezen")
	}
	if h.PagefileKnown {
		fmt.Printf("Pagefile         : %.1f GB", gib(h.PagefileBytes))
		if h.PagefilePaths != "" {
			fmt.Printf(" (%s)", h.PagefilePaths)
		}
		fmt.Println()
		if h.PagefileBytes == 0 {
			fmt.Println("WAARSCHUWING     : pagefile lijkt uitgeschakeld; voor zeer grote runs wordt een pagefile op een snelle SSD/NVMe aanbevolen.")
		}
	} else {
		fmt.Println("Pagefile         : niet betrouwbaar uitgelezen")
	}
	if h.FreeKnown {
		fmt.Printf("Vrije uitvoerruimte: %.1f GB\n", gib(h.FreeBytes))
	}
	fmt.Printf("Standaard workers: %d (50%% van %d threads)\n", defaultWorkers(h.LogicalThreads), h.LogicalThreads)
}

func gib(n int64) float64 { return float64(n) / (1024 * 1024 * 1024) }

func pagefileHelpText() string {
	return `Aanbevolen systeeminstelling voor grote databases

Voor zeer grote Source2Metal-runs kan een ruime Windows-pagefile op een snelle
SSD/NVMe extra stabiliteit geven. Een pagefile vervangt geen RAM, maar vergroot
de beschikbare commit-reserve van Windows. Schakel de pagefile bij voorkeur
niet volledig uit.

Windows 11:
1. Win+R
2. typ: sysdm.cpl
3. Geavanceerd -> Prestaties: Instellingen
4. Geavanceerd -> Virtueel geheugen: Wijzigen
5. desgewenst "Wisselbestandsgrootte automatisch beheren" uitvinken
6. kies een snelle SSD/NVMe
7. kies "Systeem beheerde grootte" of een aangepaste grootte
8. klik Instellen en herstart Windows

Bij 32 GB RAM is 32-64 GB als ruime handmatige reserve een praktische keuze
voor zeer grote databases, mits voldoende vrije schijfruimte beschikbaar is.
Source2Metal wijzigt Windows-instellingen nooit zelf.`
}
