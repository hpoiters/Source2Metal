Source2Metal v2.0.0-beta3
=========================

DOEL
Source2Metal wordt de gezamenlijke Source2Metal-pijplijn voor RAW en METAL.
Beta3 is vooral bedoeld om de infrastructuur en rustige voortgang in de praktijk te testen.

WAT BETA3 AL DOET
- Recursieve broninventarisatie vanaf de map van de EXE.
- Herkent PGN, CTG, CBH en 2CBH.
- Slaat !Source2Metal_Output en andere *_output-mappen over.
- Bouwt RAW_GAMES uit PGN.
- Hoofdvariant blijft behouden; commentaar en PGN-varianten worden verwijderd.
- Exacte partijduplicaten worden verwijderd op basis van zetten + resultaat.
- Maximaal aantal ply, minimumlengte, Elo-filter en Elo-verschil instelbaar.
- Echte parallelle PGN-verwerking via worker-pool.
- Hardwaredetectie: logische CPU-threads; op Windows ook CPU-naam, RAM,
  pagefile en vrije uitvoerruimte voor zover PowerShell/CIM dit kan uitlezen.
- Standaard workers = 50% van de gedetecteerde logische threads.
- Rustige voortgang met percentage, RAW, duplicaten, afwijzingen, partijen/s, MB/s, verstreken tijd en ETA.
- Na ieder PGN-bestand een expliciete bestandssamenvatting (gezien/RAW/duplicaten/afgewezen).
- Tijdstempelmap met RAW/GAMES, RAW/BOOKS, RAW/COMBINED, METAL, REPORT en TEMP.
- TEMP wordt na een geslaagde run verwijderd.
- Rapport, instellingen, broninventaris en SHA-256-bestand.
- De EXE bevat een bronarchive die met -extract-source kan worden uitgepakt.

NOG NIET IN BETA3
- CBH/2CBH inhoudelijk uitlezen.
- CTG naar RAW_BOOKS koppelen.
- RAW_COMBINED bouwen uit GAMES + BOOKS.
- Volledige legale schaakbordvalidator voor PGN.
- METAL Evidence Engine / Fritz Learning Encoder.

AANBEVOLEN EERSTE TEST
Workers: Enter (50%)
Modus : 3
MaxPly: 100
MinPly: 24
Elo   : 0
Gap   : 0

BRONEXTRACTIE UIT DE EXE
Open een opdrachtprompt in de map van de EXE en voer uit:

  Source2Metal_v2.0.0-beta3.exe -extract-source

Daarmee wordt naast de EXE gemaakt:

  Source2Metal_v2.0.0-beta3_EXTRACTED_SOURCE.zip

Build-info:
  Source2Metal_v2.0.0-beta3.exe -build-info

Pagefile-uitleg:
  Source2Metal_v2.0.0-beta3.exe -pagefile-help

PAGEFILE
Source2Metal wijzigt Windows-instellingen nooit. Voor grote databases is het
verstandig de Windows-pagefile niet uit te schakelen. Een ruime pagefile op een
snelle SSD/NVMe kan extra stabiliteit geven wanneer de commit-reserve krap wordt.

LICENTIE
Zie LICENSE_GPL-3.0.txt.

Beta3 voortgang
---------------
Tijdens RAW-verwerking gebruikt beta3 opnieuw één rustige voortgangsbalk per
PGN. De afkortingen zijn:
  P   = verwerkte partijen
  RAW = geaccepteerde RAW-partijen
  dup = exacte duplicaten
  afw = afgewezen partijen
  W   = actieve workers
  T   = verstreken tijd
  ETA = geschatte resterende tijd

Voor de standaard regressietest kan interactief overal Enter worden gebruikt:
workers = 50% van gedetecteerde logische threads, modus = RAW + METAL-status,
maximale diepte = 100 ply, minimumlengte = 24 ply, bronselectie behouden en
geen maximaal Elo-verschil.
