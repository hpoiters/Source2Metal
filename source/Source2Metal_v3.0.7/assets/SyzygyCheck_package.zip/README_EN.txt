SyzygyCheck v2.0.7 - All-Language
===================================

PURPOSE
SyzygyCheck verifies Syzygy tablebase files with the extensions .rtbw and .rtbz.
Other EGTB formats are not checked.

USE
1. Put SyzygyCheck_v2.0.7.exe in the exact folder you want to check.
2. Start the EXE and choose "Check Syzygy files" or press Enter.
3. Only .rtbw/.rtbz files DIRECTLY in the same folder as the EXE are checked.
   Parent folders and subfolders are never scanned.
4. An error may appear briefly as live feedback during checking. The definitive
   error result is always shown directly BELOW the final "Done:" line.

PROGRESS
The active progress display uses ONE adaptive physical console line. Example:

  [██████████░░░░░░░░░░] 47% data | 40/56 | KRBNNvKN.rtbz | 145.3 MB | 00:13 | ETA ca. 15:30

The compact labels "data" and "ETA ca." are identical in every language.
The filename is shown with its .rtbw or .rtbz extension. The percentage is weighted
by total file size. ETA is estimated from the actually measured speed of completed
files. Successful files add no new console lines and raw helper output stays hidden.

RESIZE SAFETY
The progress line is rebuilt to fit the CURRENT console width. If Windows Terminal
is resized while checking, SyzygyCheck clears the reflowed progress screen and
redraws the current state cleanly. At completion the screen is cleared once more
and only the definitive result is shown.

LANGUAGES
English, German, Dutch, French, Spanish, Chinese and Russian. The selected language
is stored in the Windows user profile and can always be changed from the main menu.
No SyzygyCheck.ini is created beside the EXE.

LANGUAGE MENU
The seven choices are displayed as English (English), Deutsch (German), Nederlands (Dutch), Français (French), Español (Spanish), 中文 (Chinese) and Русский (Russian). The English names in parentheses make the choices recognizable across languages.

ESCAPE ROUTE
In the English, Chinese and Russian main menus, the Change language option also
shows the other two main languages in parentheses. This keeps the way back
recognizable even after an accidental language choice.

TECHNICAL NOTE
The proven tbcheck checksum engine is used unchanged. If an internal temporary
executable is required, it exists only in the Windows TEMP folder and is removed
after normal completion. The EGTB folder stays clean.

IF AN ERROR IS FOUND
Replace the reported damaged .rtbw or .rtbz file with a fresh copy and run
SyzygyCheck again.

Fresh Syzygy tablebases:
https://tablebase.lichess.ovh/tables/standard/
https://tablebase.sesse.net/syzygy/

FINAL RESULT
The error line deliberately reads: what is wrong -> which file. Example:
  ERROR: checksum mismatch - KRRNvK(FailTest).rtbw

OUTPUT ISOLATION
The raw stdout/stderr of the internal tbcheck engine is fully captured. Lines such as "path: FAIL!" are never printed directly; only the translated SyzygyCheck error line is shown.

UI RESET AFTER LANGUAGE CHANGE
After a language change, the old screen is cleared. SyzygyCheck redraws only its normal header and the main menu in the newly selected language, so no confusing remnants of the previous language remain visible.
