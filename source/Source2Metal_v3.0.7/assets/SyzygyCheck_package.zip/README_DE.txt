SyzygyCheck v2.0.7 - Alle Sprachen
====================================

ZWECK
SyzygyCheck prüft Syzygy-Tablebase-Dateien mit den Endungen .rtbw und .rtbz.
Andere EGTB-Formate werden nicht geprüft.

VERWENDUNG
1. Legen Sie SyzygyCheck_v2.0.7.exe genau in den zu prüfenden Ordner.
2. Starten Sie die EXE und wählen Sie "Syzygy-Dateien prüfen" oder drücken Sie Enter.
3. Es werden nur .rtbw/.rtbz-Dateien DIREKT im selben Ordner wie die EXE geprüft.
   Übergeordnete Ordner und Unterordner werden nicht durchsucht.
4. Ein Fehler darf während der Prüfung kurz als Live-Meldung erscheinen. Das
   endgültige Fehlergebnis steht nach Abschluss immer direkt UNTER "Fertig:".

FORTSCHRITT
Die aktive Fortschrittsanzeige verwendet EINE adaptive physische Konsolenzeile. Beispiel:

  [██████████░░░░░░░░░░] 47% data | 40/56 | KRBNNvKN.rtbz | 145.3 MB | 00:13 | ETA ca. 15:30

Die kurzen Angaben "data" und "ETA ca." sind in allen Sprachen gleich. Der Dateiname
bleibt mit .rtbw oder .rtbz sichtbar. Der Prozentwert wird nach der gesamten Dateigröße
gewichtet. ETA wird aus der gemessenen Geschwindigkeit bereits abgeschlossener Dateien
geschätzt. Erfolgreiche Dateien erzeugen keine neuen Konsolenzeilen; die rohe
Helferausgabe bleibt verborgen.

FENSTERGRÖSSE
Die Fortschrittszeile wird an die AKTUELLE Konsolenbreite angepasst. Wird Windows
Terminal während der Prüfung vergrößert oder verkleinert, löscht SyzygyCheck die
durch Reflow entstandenen Reste und zeichnet den aktuellen Zustand sauber neu.
Nach Abschluss wird erneut gelöscht und nur das endgültige Ergebnis angezeigt.

SPRACHEN
Englisch, Deutsch, Niederländisch, Französisch, Spanisch, Chinesisch und Russisch.
Die gewählte Sprache wird im Windows-Benutzerprofil gespeichert und kann jederzeit
im Hauptmenü geändert werden. Neben der EXE wird keine SyzygyCheck.ini angelegt.

SPRACHMENÜ
Die sieben Optionen werden als English (English), Deutsch (German), Nederlands (Dutch), Français (French), Español (Spanish), 中文 (Chinese) und Русский (Russian) angezeigt. Die englischen Namen in Klammern erleichtern die internationale Erkennung.

TECHNIK
Die bewährte tbcheck-Prüfengine wird unverändert verwendet. Falls intern eine
temporäre EXE benötigt wird, liegt sie nur im Windows-TEMP-Ordner und wird nach
normalem Abschluss entfernt. Der EGTB-Ordner bleibt sauber.

AUSGABE-ISOLIERUNG
Die rohe stdout/stderr-Ausgabe der internen tbcheck-Engine wird vollständig abgefangen. Zeilen wie "Pfad: FAIL!" werden niemals direkt angezeigt; sichtbar ist nur die übersetzte SyzygyCheck-Fehlerzeile.

RÜCKWEG
In den englischen, chinesischen und russischen Hauptmenüs zeigt die Option
„Sprache ändern“ zusätzlich die beiden anderen Hauptsprachen in Klammern. So
bleibt der Weg zurück auch nach einer versehentlichen Sprachwahl erkennbar.

ENDRESULTAT
Die Fehlerzeile liest sich bewusst: was ist falsch -> welche Datei. Beispiel:
  FEHLER: Prüfsumme stimmt nicht überein - KRRNvK(FailTest).rtbw

UI-RESET NACH SPRACHWECHSEL
Nach einem Sprachwechsel wird der alte Bildschirm gelöscht. SyzygyCheck zeigt danach nur den normalen Programmkopf und das Hauptmenü in der neu gewählten Sprache, sodass keine verwirrenden Reste der vorherigen Sprache sichtbar bleiben.
