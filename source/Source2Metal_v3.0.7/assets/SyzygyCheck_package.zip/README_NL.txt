SyzygyCheck v2.0.7 - Alle talen
=================================

DOEL
SyzygyCheck controleert Syzygy-tablebasebestanden met de extensies .rtbw en .rtbz.
Andere EGTB-formaten worden niet gecontroleerd.

GEBRUIK
1. Plaats SyzygyCheck_v2.0.7.exe in precies de map die u wilt controleren.
2. Start de EXE en kies "Syzygy-bestanden controleren" of druk op Enter.
3. Alleen .rtbw/.rtbz-bestanden DIRECT in dezelfde map als de EXE worden gecontroleerd.
   Er wordt niet in bovenliggende mappen en niet in submappen gezocht.
4. Een fout mag tijdens de controle kort als live-melding verschijnen. Het definitieve
   foutresultaat staat na afloop altijd direct ONDER de regel "Klaar:".

VOORTGANG
De actieve voortgang gebruikt ÉÉN adaptieve fysieke consoleregel. Voorbeeld:

  [██████████░░░░░░░░░░] 47% data | 40/56 | KRBNNvKN.rtbz | 145.3 MB | 00:13 | ETA ca. 15:30

De korte aanduidingen "data" en "ETA ca." zijn in alle talen gelijk. De bestandsnaam
blijft met .rtbw of .rtbz zichtbaar. Het percentage is gewogen naar de totale
bestandsgrootte. ETA wordt geschat uit de werkelijk gemeten snelheid van reeds
voltooide bestanden. Succesvolle bestanden voegen geen nieuwe consoleregels toe
en de ruwe helperuitvoer blijft volledig verborgen.

SCHUIF-/RESIZEBESTENDIG
De voortgangsregel wordt telkens passend gemaakt voor de ACTUELE consolebreedte.
Als Windows Terminal tijdens de controle wordt vergroot of verkleind, wist
SyzygyCheck het door reflow vervormde voortgangsscherm en tekent de actuele toestand
schoon opnieuw. Na afloop wordt het scherm nogmaals gewist en verschijnt alleen het
definitieve eindresultaat.

TALEN
Engels, Duits, Nederlands, Frans, Spaans, Chinees en Russisch. De gekozen taal
wordt in het Windows-gebruikersprofiel bewaard en kan altijd via het hoofdmenu
worden gewijzigd. Er komt geen SyzygyCheck.ini naast de EXE.

TAALMENU
De zeven keuzes worden getoond als English (English), Deutsch (German), Nederlands (Dutch), Français (French), Español (Spanish), 中文 (Chinese) en Русский (Russian). De Engelse namen tussen haakjes maken de keuzes internationaal herkenbaar.

TECHNIEK
De bewezen tbcheck-checksumengine wordt ongewijzigd gebruikt. Indien intern een
tijdelijk uitvoerbestand nodig is, staat dit uitsluitend in de Windows TEMP-map
en wordt het na normale voltooiing opgeruimd. De EGTB-map blijft schoon.

BIJ EEN FOUT
Vervang een gemeld beschadigd .rtbw- of .rtbz-bestand door een fris exemplaar en
voer SyzygyCheck daarna opnieuw uit.

Verse Syzygy-tablebases:
https://tablebase.lichess.ovh/tables/standard/
https://tablebase.sesse.net/syzygy/

EINDRESULTAAT
De foutregel leest bewust als: wat is er fout -> in welk bestand. Voorbeeld:
  FOUT: checksum komt niet overeen - KRRNvK(FailTest).rtbw

UITVOERISOLATIE
De ruwe stdout/stderr-uitvoer van de interne tbcheck-engine wordt volledig opgevangen. Regels zoals "pad: FAIL!" worden nooit rechtstreeks getoond; alleen de vertaalde SyzygyCheck-foutregel verschijnt.

TERUGWEG
In de Engelse, Chinese en Russische hoofdmenu's toont de optie „Taal wijzigen“
ook de andere twee hoofdtalen tussen haakjes. Zo blijft de weg terug herkenbaar,
ook wanneer per ongeluk een onbekende taal is gekozen.

UI-RESET NA TAALWISSEL
Na een taalwissel wordt het oude scherm gewist. SyzygyCheck toont daarna alleen opnieuw de normale programmakop en het hoofdmenu in de nieuw gekozen taal, zodat geen verwarrende resten van de vorige taal zichtbaar blijven.
