SyzygyCheck v2.0.7 - Toutes langues
=====================================

OBJECTIF
SyzygyCheck vérifie les fichiers de tables Syzygy .rtbw et .rtbz. Les autres
formats EGTB ne sont pas vérifiés.

UTILISATION
1. Placez SyzygyCheck_v2.0.7.exe exactement dans le dossier à vérifier.
2. Lancez l'EXE et choisissez la vérification, ou appuyez sur Entrée.
3. Seuls les fichiers .rtbw/.rtbz DIRECTEMENT dans le même dossier que l'EXE sont
   vérifiés. Aucun dossier parent ni sous-dossier n'est parcouru.
4. Une erreur peut apparaître brièvement pendant le contrôle. Le résultat
   définitif des erreurs est toujours affiché directement SOUS « Terminé : ».

PROGRESSION
La progression active utilise UNE seule ligne physique adaptative. Exemple :

  [██████████░░░░░░░░░░] 47% data | 40/56 | KRBNNvKN.rtbz | 145.3 MB | 00:13 | ETA ca. 15:30

Les indications "data" et "ETA ca." restent identiques dans toutes les langues.
Le nom conserve l’extension .rtbw ou .rtbz. Le pourcentage est pondéré par la taille
totale des fichiers et l’ETA est estimée d’après la vitesse réellement mesurée des
fichiers déjà terminés. Les fichiers corrects n’ajoutent aucune nouvelle ligne et
la sortie brute de l’outil interne reste masquée.

REDIMENSIONNEMENT
La ligne de progression est adaptée à la largeur ACTUELLE de la console. Si Windows
Terminal est redimensionné pendant le contrôle, SyzygyCheck efface les traces dues
au reflow et redessine proprement l’état courant. À la fin, l’écran est nettoyé une
dernière fois et seul le résultat définitif est affiché.

LANGUES
Anglais, allemand, néerlandais, français, espagnol, chinois et russe. Le choix est
mémorisé dans le profil utilisateur Windows et reste modifiable depuis le menu.
Aucun fichier SyzygyCheck.ini n'est créé à côté de l'EXE.

MENU DES LANGUES
Les sept choix sont affichés comme English (English), Deutsch (German), Nederlands (Dutch), Français (French), Español (Spanish), 中文 (Chinese) et Русский (Russian). Les noms anglais entre parenthèses rendent les choix reconnaissables internationalement.

RÉSULTAT FINAL
La ligne d’erreur suit volontairement : problème -> fichier concerné. Exemple :
  ERREUR : la somme de contrôle ne correspond pas - KRRNvK(FailTest).rtbw

ISOLATION DE LA SORTIE
La sortie stdout/stderr brute du moteur tbcheck interne est entièrement capturée. Les lignes telles que « chemin : FAIL! » ne sont jamais affichées directement ; seule la ligne d’erreur traduite de SyzygyCheck apparaît.

RETOUR À UNE LANGUE CONNUE
Dans les menus principaux anglais, chinois et russe, l’option « Changer de langue »
affiche aussi entre parenthèses les deux autres langues principales. Le chemin de
retour reste ainsi reconnaissable même après un choix de langue accidentel.

RÉINITIALISATION DE L’INTERFACE APRÈS CHANGEMENT DE LANGUE
Après un changement de langue, l’ancien écran est effacé. SyzygyCheck réaffiche uniquement l’en-tête normal et le menu principal dans la nouvelle langue, sans laisser de traces déroutantes de la langue précédente.
