SyzygyCheck v2.0.7 - Todos los idiomas
========================================

OBJETIVO
SyzygyCheck comprueba archivos de tablas Syzygy con extensiones .rtbw y .rtbz.
No se comprueban otros formatos EGTB.

USO
1. Coloque SyzygyCheck_v2.0.7.exe exactamente en la carpeta que desea comprobar.
2. Inicie el EXE y elija la comprobación, o pulse Enter.
3. Solo se comprueban archivos .rtbw/.rtbz DIRECTAMENTE en la misma carpeta que
   el EXE. No se buscan carpetas superiores ni subcarpetas.
4. Un error puede aparecer brevemente durante la comprobación. El resultado
   definitivo de errores se muestra siempre justo DEBAJO de « Completado: ».

PROGRESO
El progreso activo utiliza UNA sola línea física adaptable. Ejemplo:

  [██████████░░░░░░░░░░] 47% data | 40/56 | KRBNNvKN.rtbz | 145.3 MB | 00:13 | ETA ca. 15:30

Las etiquetas "data" y "ETA ca." son iguales en todos los idiomas. El nombre mantiene
la extensión .rtbw o .rtbz. El porcentaje se pondera por el tamaño total y la ETA
se estima con la velocidad realmente medida de los archivos ya terminados. Los
archivos correctos no añaden líneas nuevas y la salida bruta interna permanece oculta.

CAMBIO DE TAMAÑO
La línea de progreso se adapta al ancho ACTUAL de la consola. Si Windows Terminal
se redimensiona durante la comprobación, SyzygyCheck borra los restos producidos por
el reflow y vuelve a dibujar limpiamente el estado actual. Al terminar, limpia otra
vez la pantalla y muestra únicamente el resultado definitivo.

IDIOMAS
Inglés, alemán, neerlandés, francés, español, chino y ruso. El idioma elegido se
guarda en el perfil de usuario de Windows y siempre puede cambiarse desde el menú.
No se crea SyzygyCheck.ini junto al EXE.

MENÚ DE IDIOMAS
Las siete opciones se muestran como English (English), Deutsch (German), Nederlands (Dutch), Français (French), Español (Spanish), 中文 (Chinese) y Русский (Russian). Los nombres en inglés entre paréntesis facilitan el reconocimiento internacional.

RESULTADO FINAL
La línea de error sigue deliberadamente: problema -> archivo afectado. Ejemplo:
  ERROR: la suma de comprobación no coincide - KRRNvK(FailTest).rtbw

AISLAMIENTO DE SALIDA
La salida stdout/stderr sin procesar del motor tbcheck interno se captura por completo. Las líneas como "ruta: FAIL!" nunca se muestran directamente; solo aparece la línea de error traducida de SyzygyCheck.

RUTA DE REGRESO
En los menús principales en inglés, chino y ruso, la opción « Cambiar idioma »
muestra también entre paréntesis los otros dos idiomas principales. Así, la ruta
de regreso sigue siendo reconocible incluso tras elegir un idioma por accidente.

REINICIO DE LA INTERFAZ TRAS CAMBIAR DE IDIOMA
Después de cambiar de idioma se limpia la pantalla anterior. SyzygyCheck vuelve a mostrar únicamente la cabecera normal y el menú principal en el nuevo idioma, sin restos confusos del idioma anterior.
